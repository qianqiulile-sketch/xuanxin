# Dia — The first complete offline AI companion for Android, built on Gemma 4 + LiteRT-LM

*Eight AI experiences from a single on-device Gemma 4 model running entirely on the phone. Chat, vision, automation, on-screen guidance, handwriting tutor, voice room, smart-home control, and a floating bubble — all from one local Gemma 4 engine. No cloud, no account, no bill.*

---

## The problem

Two and a half billion people are not online today. Networks fail. Disasters cut wires. Outages happen everywhere. Even in this age of AI, remote areas still have no signal.

Some people can't use a phone at all. A grandmother who can't find the camera button. A migrant worker who can't read the language on a medicine bottle. A child whose school can't afford a tutor. A blind user whose phone reads their notifications but won't act on them.

Every meaningful AI assistant on Earth today — ChatGPT, Gemini, Claude, Copilot — is a thin client over a cloud API. Cut the wire and they fall silent. The four billion smartphones in the world's hands belong, on most days, to the half of humanity that doesn't have reliable connectivity. AI is a luxury for the connected.

**Dia is the first complete AI assistant that works for everyone else.**

---

## What Dia is

Dia is a single Android app hosting **eight distinct AI experiences**, all sharing one on-device Gemma 4 engine.

| Mode | What it does |
|------|--------------|
| **Chat** | Streaming conversational assistant with **Audio Scribe** (Gemma 4's official audio understanding), persistent chat history, model switching, reasoning trace, image input, markdown, and TTS. |
| **Lens** | Pick any photo, ask anything. Vision answers, fully offline. |
| **Lens Live** | Real-time camera with three sub-modes — **Think** (Describe / Answer / Solve, with an optional Thinking-mode for deep reasoning), **Translate** (auto-loop, auto-speaker, picker for any target language), **Guide** (ask about your surroundings, Gemma replies and annotates with bounding boxes). Auto-fires when you hold the phone still — accelerometer-driven. |
| **Guide** (on-screen) | Step-by-step on-screen tutor. Speak the goal, Dia overlays a glass cursor and walks you through any app, with a live plan + step-by-step panel. |
| **Pilot** | Autonomous phone automation via Accessibility Services. Type or speak the goal, Dia drives the apps. Local Gemma orchestrates by default; harder long-horizon tasks can route to a cloud Gemma via Ollama or any OpenAI-compatible endpoint. |
| **Slate** | A multi-page handwriting **Notebook** saved to local storage — write or draw, Gemma reads and writes back in handwriting on the same page. Plus a **Quiz** mode that generates 10 questions on any topic and grades scribbled answers visually. |
| **Home** | Voice-first room. Tap the orb, speak, hear back. Soft wake word ("Hey Dia"). **Home Assistant integration** controls any smart device — lights, locks, fans, climate, scenes, scripts — via HA's 2,000+ integration ecosystem. |
| **Bubble** | A draggable floating bubble over every app. Translate, Summarise, Answer, Solve, or Ask about a region of the current screen — Dia is your buddy in any app. |

All eight share **one loaded Gemma 4 engine**, one process, one app. Every byte of inference happens on the user's device.

---

## The model: Gemma 4 E2B — two billion parameters that fit in your pocket

We deliberately built Dia around **Gemma 4 E2B**, the smallest multimodal Gemma 4. Not E4B. Not the 26B. Not the 31B. The 2B.

Here is why that matters.

The 2B model is the one that **actually runs on the phone in your hand right now**. ~4 GB on disk after quantisation, ~3 GB resident in RAM during inference. It does not need a flagship; an 8 GB Samsung mid-range from three years ago is enough. That is the device most of the world owns. If we had targeted E4B or a 26B-class model, this entire project would have collapsed into "interesting demo for people with $1,200 phones," which is the opposite of why we built it.

Every story Dia tells works *because* the model is small:

- **The grandmother in a tier-3 city.** Her phone is six years old. 8 GB RAM. No 5G. Dia runs.
- **The migrant worker.** Cheap Android with 6 GB RAM. Dia runs.
- **The schoolchild sharing a phone with three siblings.** Used hardware. Dia runs.
- **You, on a flight, on a trail, in a basement, in a power cut.** Your premium phone. Dia runs.

Cloud is not the headline. Cloud is a **user choice** in Settings, hidden behind a toggle, off by default. You opt in if you want to push a giant Pilot task to a 31B Gemma via Ollama or any OpenAI-compatible endpoint. Most of the time you won't. The 2B is the one doing the work.

This is the entire thesis: **a 2-billion-parameter model, used well, beats a 31B model that needs a network for 95% of the things people actually want a phone assistant to do.**

---

## Architecture

### The runtime

Dia is built around **`com.google.ai.edge.litertlm`** — Google AI Edge's LiteRT-LM runtime — wrapped in a single application-scope `DiaEngine` singleton. The engine wraps Gemma 4 `.litertlm` weights loaded from device storage and exposes streaming generation, multimodal input (text + image + audio), and per-feature `Conversation` slots so a long Pilot run never pollutes Chat history.

```
            Compose UI (8 features)
                    │
                    ▼
            BackendRouter ── Local / Cloud (optional Ollama, OpenAI, etc.)
                    │
                    ▼
            DiaEngine (singleton, mutex-serialised)
                    │
                    ▼
            LiteRT-LM Engine (Gemma 4)
            GPU first → CPU fallback
            MTP / speculative decoding
```

**Single Activity, Compose-only, Navigation3.** Foreground services keep critical workloads alive (`PilotForegroundService`, `GuideOverlayService`, `ScreenTranslateService`, `QuickActionService`, `DiaQuickLaunchService`). A single `DiaAccessibilityService` (declared `android:isAccessibilityTool="true"`, with `flagRetrieveInteractiveWindows`) is the workhorse for Pilot, Guide, Bubble, and screen translate — building 250-node compact accessibility trees with EDIT / TAP / MIC / CAM markers, dispatching gestures synchronously via `CountDownLatch`, and capturing screenshots via `takeScreenshot()` on Android 11+.

### Concurrency safety

`ModelManager` serialises every load and unload through a `Mutex`, short-circuits "same model already loaded," and exposes one observable `ModelLoadState` that every feature renders. A 7-attempt exponential-backoff retry handles the `FAILED_PRECONDITION: A session already exists` race that LiteRT-LM throws when two coroutines hit the engine concurrently. This race was the single hardest engineering problem on the project.

---

## How we use Gemma 4

This is the section that proves the demo is real. Every Gemma 4 capability the brief asks about is wired into a feature.

### LiteRT-LM as the inference runtime

We use `com.google.ai.edge.litertlm` directly. Models load **from device storage** at runtime — drop a Gemma 4 `.litertlm` file in Downloads and the Model Setup screen lets you pick it. Validated against Gemma 4 E2B multimodal (~4 GB on disk) end-to-end on Samsung Galaxy S23 (8 GB RAM) and S24 Ultra (12 GB RAM).

### Multi-Token Prediction (MTP)

We turn on **`ExperimentalFlags.enableSpeculativeDecoding = true`** before every engine init and reset it right after. Per Google's LiteRT-LM Gemma 4 guidance, MTP gives a meaningful decode speedup on both GPU and CPU with no quality loss. This directly improves the "feels live" judgement on Lens Live, Pilot, and Audio Scribe.

### GPU acceleration with CPU fallback

Lens, all four Lens Live sub-modes, and Slate run vision through the **GPU backend** by default. Initialization tries GPU first; on devices without OpenCL support, we fall back to CPU automatically without restarting the app. Audio backend stays on CPU for stability.

### Reasoning (Thinking mode)

Chat exposes a Thinking toggle — on by default in Settings — that surfaces Gemma 4's reasoning trace alongside the final answer. We pass `thinking = true` to the engine, capture both thought and response in separate streaming callbacks, and render the trace collapsibly above the answer.

Lens Live Think reuses the same capability: by default it returns terse, direct answers; tap the top Thinking button and Gemma's deeper reasoning + a longer explanation appears. Same model, two prompt + display modes.

### Function calling / tool calling

**Pilot is a full tool-calling agent.** We define 14 tools — `open_app`, `tap_node`, `find_and_tap`, `input_text`, `system_key`, `search_in_app`, `get_screen_info`, `get_device_info`, `take_screenshot`, `swipe`, `scroll`, `wait`, `open_url`, `finish` — and prompt Gemma 4 with a JSON tool-call protocol. The model emits one JSON object per turn:

```json
{"tool": "search_in_app", "params": {"app": "Spotify", "query": "Taylor Swift"}}
```

A brace-balanced streaming-aware extractor parses the JSON even when output is truncated. Three-level stuck detection keeps the agent moving — hint nudge, then strategy switch, then forced submit. The accessibility tree is trimmed to a 1,800-character budget so the prompt fits in 4,096 tokens.

**Home** mode uses the same pattern with HA-specific tools — `ha_call_service`, `ha_get_state`, `ha_list_entities`, `respond` — letting Gemma 4 decide whether to flip a switch, query state, list devices, or just answer.

### Multimodal image understanding

Five features push images directly into Gemma 4 as `Bitmap`s — no OCR, no preprocessing pipeline. Lens, all four Lens Live sub-modes, Slate, Bubble, and Screen Translate all use Gemma 4's native vision encoder. Slate renders user ink to a 1024-px crop and asks Gemma to read handwriting; Lens Live Translate captures every 2.2 s and overlays English captions live; Bubble's region-select-then-ask flow captures any region of any app.

### Audio Scribe (audio understanding)

Chat has an **Audio Scribe** mode — Gemma 4's official audio understanding capability, end-to-end. We capture 16 kHz / 16-bit mono PCM via `AudioRecord`, wrap it as WAV with a 44-byte header (LiteRT-LM's miniaudio decoder needs the container), and pass it as `Content.AudioBytes` directly to Gemma 4 — **no separate STT model in the pipeline**. Gemma 4 transcribes-and-responds in one shot, so accents and cross-language speech stay in the model's context. The result is blazing-fast voice chat that feels native to the model.

### Bounding-box grounding (Lens Live Guide)

Lens Live Guide asks Gemma 4 a question like *"where is the power button?"* over a camera frame. The system prompt instructs Gemma to return both an answer **and** a normalised box:

```
The plug is in the bottom-right corner.
[BOX:0.62,0.71,0.94,0.96]
```

We parse the box, freeze the camera frame, and overlay the spotlight on the exact pixels Gemma reasoned about. **Grounding without any custom detection model — pure Gemma 4.**

### Optional cloud routing

Dia is offline by default. Settings → Backend can route requests to any OpenAI-compatible endpoint — **Ollama** for self-hosted, OpenAI, OpenRouter, Gemini, LM Studio. The API surface stays identical — every call site uses `BackendRouter` so cloud is one switch away. Pilot uses this hook to push the hardest tasks to a stronger cloud Gemma while keeping everything else local.

---

## What makes Slate's Quiz mode special

This is the demo that makes the **Future of Education** track click. In a normal app, a quiz auto-grader is exact-string matching: *"4"* passes, *"four"* fails. In Slate, the user **scribbles or draws their answer** — a number, a written word, a sketch of four objects, an equation, anything. Both the page (with the question) and the user's drawing get rendered as a Bitmap and sent to Gemma 4 for evaluation.

Gemma's image understanding evaluates **intent**, not exact strings. *"4"*, *"four"*, *"FOUR"*, *"IV"*, or four hand-drawn dots all evaluate to correct. Wrong answers get the canonical answer written back in red ink at the bottom of the page in synthesized handwriting.

This is a tutor that grades like a human — and it's only possible because Gemma 4 is multimodal, on-device, and free to call as many times as the student needs.

---

## Engineering challenges

**The session race.** LiteRT-LM's `FAILED_PRECONDITION: A session already exists` was the worst bug. Two coroutines hitting the engine concurrently destroyed the JNI state. Solved with a single `Mutex` in `ModelManager` plus 7-attempt exponential-backoff retry on every conversation init. Every feature now serialises through one observable state.

**Samsung One UI overlay touch blocking.** Guide's overlay was eating the user's tap on Samsung phones. Solved with view-level `dispatchTouchEvent → false` plus auto-hide-after-1.5s.

**Compose perf regression in Slate.** A `currentStroke = s` snapshot copy on every pointer sample was killing frame rate. Fixed with a `liveStrokeTick` Int counter that bumps once per frame instead of mutating the stroke object.

**Token overflow in Pilot.** Solved with brace-balanced JSON extraction (so truncated output still parses) plus EDIT-aware screen-tree trimming to a 1,800-char budget.

**Premature finish in Guide.** Re-planning on `TYPE_WINDOW_CONTENT_CHANGED` made Guide jump ahead before the user tapped. Fixed by re-planning only on real `TYPE_VIEW_CLICKED` events.

**Camera stutter in Lens Live.** Re-binding the camera on every sub-mode switch caused video pauses. Fixed by binding once and keeping the same `PreviewView` across modes.

---

## Settings & accessibility — every toggle, what it does, who it serves

Dia is built accessibility-first. Settings is structured so nobody has to hunt.

**Backend (where requests run).**
- *Local only* — default. Every byte of inference on the device. Gemma 4 E2B does the work.
- *Cloud only* — the user's explicit opt-in. Configure base URL, model, and API key for any OpenAI-compatible endpoint: **Ollama** (self-hosted on a home server, the recommended path), **OpenAI**, **OpenRouter**, **Gemini**, **LM Studio**. Cloud is most useful for long-horizon Pilot tasks where the 2B context window runs out, or for users who already pay for a cloud LLM.
- The API surface across **every** feature is identical regardless of backend, because every call site goes through `BackendRouter`.

**Model.**
- *Active local model* — shows the currently loaded `.litertlm` / `.task` file.
- *Auto-load on launch* — restore the last-used model when Dia opens.
- *Unload model* — frees RAM. Useful on 6 GB devices when other apps need memory.
- The Model Setup screen lets the user pick a Gemma 4 file from any folder on device storage.

**Chat.**
- *Read responses aloud* — TTS plays every assistant reply automatically. For low-vision users and tired eyes.
- *Show thinking by default* — Gemma 4's reasoning trace surfaces in new chats. For curious learners and developers debugging.
- *Clear chat memory* — wipes the conversation slot. Privacy.

**Display & accessibility.**
- *Big text* — 1.4× scale across the entire app. The cornerstone of the elderly + low-vision experience.
- *Reduce motion* — fewer animations, fewer pulses. For users with vestibular sensitivity, motion sickness, or simply distraction.
- *Auto-listen on open* — opens the mic immediately when Pilot or Guide launch. Hands-free entry for motor-impaired users.
- *Pilot speaks status* — TTS announces every tool call ("opening WhatsApp", "tapping the call button", "message sent"). Essential for blind users.

**Floating bubble.**
- *Show / hide bubble* — one tap to enable Dia floating over every app.

**Quick launch.**
- *Quick-launch notification* — a persistent notification with shortcuts to Chat / Guide / Pilot. Always one tap from any screen. Asks for `POST_NOTIFICATIONS` automatically on Android 13+.

**Permissions.**
- One-tap deep-links to Accessibility, Notification listener, Display-over-other-apps system pages so users don't have to hunt through Android Settings.

**Home Assistant.**
- *HA URL* — local IP and port (e.g. `http://192.168.1.100:8123`).
- *Long-Lived Access Token* — secure paste, masked display.
- *Wake word toggle* — soft wake word ("Hey Dia") on/off.

**Help.**
- *Replay tour* — a 10-card walkthrough of every feature with example prompts and illustrated previews. Useful when a new family member picks up the phone for the first time.

**About.**
- Version, "Built with Gemma 4 + LiteRT-LM," hackathon submission line.

### First-launch tour

A 10-card swipeable walkthrough introduces every feature on first launch with concrete *"try saying"* example chips: a hand-drawn illustration of the feature in action, a tagline, a one-paragraph description, and three real example prompts ("Order biryani on Swiggy", "Where's the cat?", "Turn off the bedroom light"). Replayable any time from Settings.

---

## Who Dia is for, feature by feature

Generic "AI for everyone" is a marketing line. We want to be precise about *which* humans Dia changes the day for, and *how*.

### Chat — for the lonely, the curious, and the offline professional

The chat panel sounds basic until you realise what it isn't. It isn't OpenAI sending your conversation to a server. It isn't a subscription. It isn't a feed.

- A **widow living alone** can talk to Dia at 2 a.m. without paying anyone, without surveillance, without anyone learning she was awake.
- A **journalist in a country with internet censorship** can brainstorm a piece without her drafts touching a server she doesn't trust.
- A **lawyer on a flight** can rewrite a paragraph mid-air with no Wi-Fi.
- A **student in a rural classroom** with one shared computer and no home internet can still ask questions all evening on a hand-me-down phone.

Sub-features that matter for these people:
- **Audio Scribe** — Gemma 4's official audio understanding. They speak instead of type. No separate STT; the model hears them directly.
- **Persistent chat history** — every conversation saved on-device, indexed in a drawer. Your relationship with Dia survives reboots.
- **Thinking mode** — for the curious who want to *see* the reasoning, not just the answer.
- **Read aloud** — for tired eyes and low-vision users.
- **Image input** — attach a photo (rash, plant, document) and ask.
- **Markdown + code blocks** — for the developer on a long flight.

### Lens — for the language-barrier worker, the new parent, the curious child

Pick a photo, ask anything. The simplest feature is also the deepest.

- A **migrant worker** photographs a medicine label written in a language they don't read. Dia reads it back in theirs.
- A **new parent** photographs an unfamiliar rash on their baby and asks if it warrants the ER tonight.
- A **homeowner** photographs a circuit breaker and asks which switch controls the kitchen.
- A **child** photographs a beetle in the garden and learns what it is.

It's the same feature. The audience is everyone with a question and a camera.

### Lens Live — for the traveller, the visually-impaired user, the field worker

Real-time vision changes the game. Three sub-modes, three audiences.

**Think (Describe / Answer / Solve).**
- **Describe** is the killer feature for **visually impaired users.** Hold the phone up; Dia narrates the room. Every door, every person, every object.
- **Answer** is for **students walking past a billboard** with a question on it, **adults at a museum**, **anyone who points at a thing and wonders.**
- **Solve** is for the **kid stuck on homework** who shows the page to Dia instead of asking a parent.
- A **Thinking** toggle adds Gemma's reasoning trace for users who want to learn *how* the answer was reached, not just what it is.

**Translate.**
- **Tourist in a country whose script they can't read.** Hold the phone over a menu, get English back, *spoken*.
- **Migrant worker reading shop signage.** Same flow.
- **Auto-loop and auto-speaker** mean they can walk down a street and have the world translated to them continuously, no taps required.
- A **language picker** lets a Spanish-speaking grandmother set her target to Spanish and translate English back.

**Guide.**
- **The grandparent** who needs to find the *power button* on a strange remote.
- **The first-time car owner** who doesn't know what the warning light means and where to look.
- **The blind user** who asks "where is the door handle?" and Dia draws a literal box on the screen.
- This is **bounding-box grounding from a 2B model** — physically pointing at the world.

**Accelerometer auto-trigger.** Hold the phone still for 2.2 seconds, the query fires automatically. No tap needed. Crucial for users with motor difficulties or hands full of grocery bags.

### Guide (on-screen) — for the elderly, the new-to-smartphone, the cognitively overwhelmed

This is the feature that wins the **Digital Equity & Inclusivity** track in our heads.

- **The grandmother who has owned a smartphone for nine years and never sent a photo.** She speaks "how do I send a photo to my granddaughter?" The cursor flies to the right button. Each step gets a yellow highlight, a finger pointer, and a big-text caption read aloud. She follows. Photo sent. She didn't have to learn anything.
- **The 14-year-old refugee** with a hand-me-down phone and no idea what an app store is.
- **The dyslexic adult** who finds normal app navigation cognitively expensive.
- **The motor-impaired user** who can speak but struggles to remember menu hierarchies.

Sub-features:
- **Re-plan only on real `TYPE_VIEW_CLICKED` events** — Guide doesn't sprint ahead before you tap. It waits, like a patient teacher.
- **Live plan + step panel** — they always know how many steps remain.
- **Auto-launch the right app** via PackageManager when needed.
- **Big text + high-contrast captions** wired through the global accessibility prefs.
- **Slow voice mode** for users who need TTS at a slower rate.

### Pilot — for the disabled, the busy, the hands-full, the night-driver

When you can't, or shouldn't, or simply don't want to navigate apps yourself.

- A **person with severe arthritis** who can speak but can't reliably tap small buttons on Swiggy. Pilot orders dinner.
- A **blind user** who cannot navigate a visual UI at all. Pilot reads notifications, sends messages, makes calls. With "Pilot speaks status" on, every action is announced.
- A **driver** who needs to message a contact without picking up the phone. Pilot composes and sends, hands-free.
- A **parent juggling a baby** who needs to set a reminder, send a payment, or order something *right now*.
- A **professional with RSI** whose hands need a break.

Sub-features:
- **14 tools, JSON tool-calling protocol** — the agent decides what to do, the runtime executes.
- **Three-level stuck detection** — hint, then strategy switch, then forced submit. Pilot doesn't loop forever.
- **Optional cloud routing for hard tasks** — when a multi-app task is too long for the 2B context window, the user can opt-in to a cloud Gemma in Settings. The 2B handles 95% of what a phone assistant is asked to do.
- **Speak status TTS** — every tool call announced aloud for blind users.
- **Auto-listen on open** — the mic opens immediately, hands-free entry.

### Slate — for children, students, dyscalculic learners, dysgraphic writers, and the right-brained

The feature with the broadest age range. From kindergarteners to adults.

**Notebook mode.**
- **A 9-year-old** in a classroom with no tutor scribbles `7 × 8 = ?` and watches Dia handwrite `56` next to it, in cursive, scaled to her handwriting.
- **A teenager studying for the SAT** writes a problem, gets a step-by-step solution back on the same page.
- **A dyslexic adult** writes a letter draft and asks Dia to read it back in clear speech.
- **An engineer sketching a circuit** asks Dia to identify a component he drew.
- **Multiple notebooks, multiple pages, autosaved** — a permanent journal that learns with you.

**Quiz mode — the education killer feature.**
- The user types a topic. Gemma 4 generates 10 questions, one per page.
- The user **scribbles or draws their answer.** A number, a word, a sketch, an equation, anything.
- Both the page and the user's drawing are sent to Gemma 4 as a Bitmap. Gemma evaluates **intent**, not exact strings.
- **`4`, `four`, `FOUR`, `IV`, four hand-drawn dots** — all evaluate to correct. Wrong answers get the canonical answer written back in **red ink** at the bottom of the page in synthesized handwriting.
- This is a tutor that grades like a human. Only possible because Gemma 4 is multimodal, on-device, and free to call as many times as the student needs.
- Forced to **local model** even when cloud is configured — handwriting Bitmaps belong on-device, full stop.

### Home — for elderly users alone at home, for families, for anyone who hates speaking to a corporation

A voice-first room with a single big animated orb. Tap it, speak, hear back.

- The **grandparent living alone** can dim the lights from the couch without standing up, without buying an Echo that listens to her all day.
- The **family** that wants whole-home voice control without giving Amazon and Google a constant feed of their living room.
- The **privacy-conscious user** running their own Home Assistant — Dia is the on-device front-end they always wanted.
- The **disabled user** who can't physically reach a switch.

Sub-features:
- **Soft wake word** — "Hey Dia / Hi Dia / OK Dia / Dia" while the screen is on. The wake phrase is stripped, so *"Hey Dia, turn off the bedroom light"* works in one breath.
- **Home Assistant REST integration** — `ha_call_service`, `ha_get_state`, `ha_list_entities`, `respond` — controls **anything** in HA's 2,000+ integration ecosystem. Lights, switches, fans, locks, climate, blinds, vacuums, scenes, scripts, automations.
- **Live entity carousel** under the orb shows every device with current state and lets you tap-toggle them.
- **STT in → Gemma 4 → TTS out** — the full voice loop, on-device, no cloud, no Amazon.

### Bubble — for the multitasker, the foreign-language reader, the student stuck on a screen

The floating bubble is Dia *anywhere*. A draggable orb on top of every app.

- A **student reading a Wikipedia article** highlights a confusing passage and asks Dia to summarise.
- A **traveller using a foreign-language airline app** taps Translate and gets the boarding screen in English.
- A **researcher reading a long PDF in another app** asks Dia for the gist.
- A **gamer wanting to know what an in-game item does** asks about the screen.
- A **person in any app** who needs an answer to a question on screen *right now*.

Sub-features:
- **Translate** — auto-detect, translate the visible screen.
- **Summarise** — the gist of what's on screen.
- **Answer** — answer any visible question.
- **Solve** — work out any visible problem.
- **Ask about screen** — *region first, then voice or type.* Drag a rectangle, then ask anything about that region. The most flexible Dia mode in the entire app.

---

## Validated on real devices

End-to-end testing on **Samsung Galaxy S23 (8 GB)** and **Samsung Galaxy S24 Ultra (12 GB)** with **Gemma 4 E2B** (~4 GB on disk, ~3 GB resident at inference). Every feature in the table above is a real code path you can run on a fresh install of the APK.

The 2B was a deliberate choice: it is the largest Gemma 4 that runs comfortably on the phones most of the world actually owns. Cloud routing is **opt-in only** — for the user who chooses to push a long-horizon Pilot task to a 31B Gemma via Ollama or any OpenAI-compatible endpoint. Most users will never need it.

---

## What's next

We have a clear roadmap and prototypes for several of these:

- **True low-power wake word** to replace the current `SpeechRecognizer`-based soft wake-word in Home mode.
- **Tablet companion with Home mode docked** — competing head-to-head with smart-home displays.
- **Laptop / desktop port via LiteRT-LM** — Chat, Guide, and a video-call mode running on Windows / macOS / Linux through LiteRT-LM or `.task` runtimes.
- **Browser build** — prototyped on the LiteRT-LM JS runtime: open a page, get Dia.
- **NPU support** — attempted on S23 and S24 Ultra; on-device model compilation isn't currently feasible with the toolchain. Tracking it for when LiteRT-LM ships first-class NPU paths.

---

## Attachments

- **Public code repository:** *<github link>*
- **Live demo (signed APK):** GitHub Releases on the repo above
- **Feature demos (Google Drive):** [https://drive.google.com/drive/folders/1wr4C-o-dtyRl4rKzKHUOPrfwPd1aOVWj?usp=sharing](https://drive.google.com/drive/folders/1wr4C-o-dtyRl4rKzKHUOPrfwPd1aOVWj?usp=sharing)
- **Demo video (YouTube):** [https://youtu.be/ZhBGNFW86kw](https://youtu.be/ZhBGNFW86kw)

---

*Dia. Offline AI. For everyone.*
*Built on Google's Gemma 4 + LiteRT-LM. Submitted to the Gemma 4 Good Hackathon, May 2026.*
