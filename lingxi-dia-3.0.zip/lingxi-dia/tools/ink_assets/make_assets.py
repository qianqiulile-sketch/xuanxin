import sys, os
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from scipy import ndimage
import inkart as K

OUT = K.OUT
SCALE = float(os.environ.get('SCALE', '1'))
W, H = int(1080 * SCALE), int(2340 * SCALE)
INK = (34, 28, 24)
which = sys.argv[2:] or ['paper', 'night', 'wuji', 'avatar', 'hero', 'brush', 'texture', 'icon']


def scene_paper():
    rng = np.random.default_rng(11)
    img = K.paper(H, W, (244, 238, 223), rng)
    # 淡朱红日
    sun = K.disc(H, W, W * 0.74, H * 0.13, W * 0.075, 3) * 0.55
    img = K.composite(img, (205, 92, 70), sun * 0.7)
    img = K.composite(img, (230, 150, 120), K.halo(H, W, W * 0.74, H * 0.13, W * 0.075) * 0.10)
    # 远山（极淡）→ 中山 → 近山，层间云雾
    layers = [
        (H * 0.62, H * 0.16, 260, 0.20, [(0.25, H * 0.08, 0.10), (0.8, H * 0.05, 0.08)], (120, 125, 128)),
        (H * 0.74, H * 0.18, 200, 0.42, [(0.62, H * 0.10, 0.09)], (78, 80, 82)),
        (H * 0.90, H * 0.20, 160, 0.78, [(0.15, H * 0.12, 0.10), (0.95, H * 0.06, 0.06)], INK),
    ]
    for i, (by, amp, sc, strength, peaks, col) in enumerate(layers):
        a, ridge = K.mountain_layer(H, W, by, amp, sc * SCALE, rng, [(px, ph, pw) for px, ph, pw in peaks])
        img = K.composite(img, col, a * strength)
        if i < 2:
            m = K.mist_band(H, W, by + amp * 0.1, H * 0.035, rng, 0.9)
            img = K.composite(img, (246, 241, 228), m)
    # 左上松枝
    pine = K.pine_mask(int(W * 0.95), int(H * 0.30), rng, origin=(0.0, 0.62), direction=1)
    canvas = np.zeros((H, W))
    K.place(canvas, pine, -W * 0.02, -H * 0.05)
    img = K.composite(img, INK, canvas * 0.78)
    # 飞鸟
    img = K.composite(img, INK, K.birds_mask(W, H, rng, 6, (0.50, 0.20, 0.30, 0.08), 18 * SCALE) * 0.7)
    # 近处小人：山脚孤舟 + 侠客（很小）
    man = K.swordsman_mask(600)
    canvas = np.zeros((H, W))
    msc = H * 0.035 / 600
    K.place(canvas, man, W * 0.60, H * 0.86, msc)
    img = K.composite(img, INK, canvas * 0.85)
    # 右下印章
    return img


def scene_night():
    rng = np.random.default_rng(23)
    base = np.array((22, 19, 17), float)
    img = np.ones((H, W, 3)) * base
    # 夜色由上到下：上方略带靛青
    yy = np.linspace(0, 1, H)[:, None]

    tint = np.zeros((H, W, 3)); tint[...] = np.array((14, 20, 30))
    img = img * 1 + tint * ((1 - yy) ** 1.6)[..., None]
    img += ((K.fbm(H, W, 280, 4, rng) - 0.5) * 16)[..., None]
    img += ((rng.random((H, W)) - 0.5) * 5)[..., None]
    # 月 + 光晕
    mx, my, mr = W * 0.70, H * 0.15, W * 0.11
    img = K.composite(img, (200, 196, 180), K.halo(H, W, mx, my, mr) * 0.20)
    moon = K.disc(H, W, mx, my, mr, 2.5)
    moon_tex = K.fbm(H, W, 40 * SCALE, 4, rng)
    img = K.composite(img, (236, 228, 205), moon * (0.82 + 0.18 * moon_tex))
    # 云纹掠过月亮
    cloud = K.mist_band(H, W, my + mr * 0.35, mr * 0.18, rng, 0.75) * (K.fbm(H, W, 120, 3, rng) > 0.45)
    img = K.composite(img, (40, 38, 40), ndimage.gaussian_filter(cloud.astype(float), 6) * 0.8)
    # 山：亮灰远山 → 深墨近山（夜里山是比天更深/更浅的灰）
    layers = [
        (H * 0.60, H * 0.15, 260, (70, 74, 82), 0.55, [(0.3, H * 0.06, 0.12)]),
        (H * 0.72, H * 0.17, 200, (48, 50, 56), 0.75, [(0.75, H * 0.09, 0.10)]),
    ]
    for by, amp, sc, col, strength, peaks in layers:
        a, _ = K.mountain_layer(H, W, by, amp, sc * SCALE, rng, peaks, rough=0.6)
        img = K.composite(img, col, a * strength)
        img = K.composite(img, (58, 58, 62), K.mist_band(H, W, by + amp * 0.12, H * 0.03, rng, 0.55))
    # 悬崖（右下）+ 侠客
    cliff = np.zeros((H, W))
    im = Image.new('L', (W, H), 0)
    d = ImageDraw.Draw(im)
    pts = [(W * 0.30, H), (W * 0.36, H * 0.86), (W * 0.47, H * 0.83), (W * 0.62, H * 0.815), (W * 0.80, H * 0.82), (W * 0.93, H * 0.80), (W, H * 0.81), (W, H)]
    d.polygon(pts, fill=255)
    cliff = np.asarray(im, float) / 255
    tex = K.fbm(H, W, 30 * SCALE, 4, rng)
    cliff = ndimage.gaussian_filter(cliff, 2) * (0.8 + 0.4 * (tex - 0.5))
    img = K.composite(img, (12, 10, 9), np.clip(cliff, 0, 1))
    man = K.swordsman_mask(900, facing=-1)
    canvas = np.zeros((H, W))
    msc = H * 0.13 / 900
    K.place(canvas, man, W * 0.60, H * 0.817 - 900 * msc * 0.93, msc)
    img = K.composite(img, (8, 7, 6), canvas)
    # 墨竹（左侧）
    bam = K.bamboo_mask(int(W * 0.5), int(H * 0.62), rng, 3)
    canvas = np.zeros((H, W))
    K.place(canvas, bam, -W * 0.04, H * 0.40)
    img = K.composite(img, (10, 9, 8), canvas * 0.92)
    # 远处飞鸟
    img = K.composite(img, (16, 14, 13), K.birds_mask(W, H, rng, 4, (0.25, 0.22, 0.3, 0.06), 16 * SCALE) * 0.8)
    return img


def scene_wuji():
    rng = np.random.default_rng(42)
    img = np.ones((H, W, 3)) * np.array((14, 12, 11), float)
    img += ((K.fbm(H, W, 300, 4, rng) - 0.5) * 14)[..., None]
    # 墨云翻涌
    swirl = K.fbm(H, W, 160, 5, rng)
    img = K.composite(img, (34, 30, 27), np.clip((swirl - 0.45) * 2.2, 0, 1) * 0.8)
    # 太极（金）
    cx, cy, R = W * 0.5, H * 0.24, W * 0.30
    yy, xx = np.mgrid[0:H, 0:W].astype(float)
    dx, dy = xx - cx, yy - cy
    r = np.sqrt(dx ** 2 + dy ** 2)
    ring = np.clip((R - r) / 2, 0, 1) - np.clip((R - 6 * SCALE - r) / 2, 0, 1)
    upper = np.sqrt(dx ** 2 + (dy + R / 2) ** 2) < R / 2
    lower = np.sqrt(dx ** 2 + (dy - R / 2) ** 2) < R / 2
    yang = ((dx > 0) | upper) & ~lower & (r < R)
    gold = (212, 168, 90)
    img = K.composite(img, gold, ndimage.gaussian_filter(yang.astype(float), 1.5) * 0.22)
    img = K.composite(img, gold, np.clip(ring, 0, 1) * 0.55)
    img = K.composite(img, gold, K.disc(H, W, cx, cy - R / 2, R * 0.12, 2) * 0.55)
    img = K.composite(img, (14, 12, 11), K.disc(H, W, cx, cy + R / 2, R * 0.12, 2) * 0.9)
    img = K.composite(img, gold, K.halo(H, W, cx, cy, R) * 0.07)
    # 八卦刻度
    im = Image.new('L', (W, H), 0)
    d = ImageDraw.Draw(im)
    for k in range(8):
        a = k * np.pi / 4
        for j in range(3):
            rr = R * (1.12 + j * 0.05)
            broken = (k >> j) & 1
            span = 0.22
            for s0, s1 in ([(-span, -0.03), (0.03, span)] if broken else [(-span, span)]):
                p0 = (cx + np.cos(a + s0) * rr, cy + np.sin(a + s0) * rr)
                p1 = (cx + np.cos(a + s1) * rr, cy + np.sin(a + s1) * rr)
                d.line([p0, p1], fill=255, width=int(7 * SCALE))
    img = K.composite(img, gold, ndimage.gaussian_filter(np.asarray(im, float) / 255, 1) * 0.35)
    # 金色微尘
    dust = (rng.random((H, W)) > 0.9993).astype(float)
    dust = ndimage.gaussian_filter(dust, 1.2) * 6
    img = K.composite(img, (240, 205, 130), np.clip(dust, 0, 1) * 0.8)
    # 山（墨金描边）
    for by, amp, col, st in [(H * 0.78, H * 0.16, (40, 36, 30), 0.9), (H * 0.92, H * 0.18, (20, 18, 16), 1.0)]:
        a, ridge = K.mountain_layer(H, W, by, amp, 200 * SCALE, rng, [(0.5, H * 0.07, 0.15)], rough=0.5)
        img = K.composite(img, col, a * st)
        edge = np.zeros((H, W))
        ys = np.clip(ridge.astype(int), 0, H - 1)
        edge[ys, np.arange(W)] = 1
        edge = ndimage.gaussian_filter(edge, 1.2) * 3
        img = K.composite(img, gold, np.clip(edge, 0, 1) * 0.35)
    return img


def make_avatar():
    S = 512
    rng = np.random.default_rng(5)
    img = K.paper(S, S, (238, 229, 210), rng, fiber=False, strength=0.6)
    # 圆相（禅圆）一笔
    yy, xx = np.mgrid[0:S, 0:S].astype(float)
    ang = (np.arctan2(yy - S / 2, xx - S / 2) + np.pi) / (2 * np.pi)
    rr = np.sqrt((xx - S / 2) ** 2 + (yy - S / 2) ** 2)
    width = 22 * (0.4 + 0.6 * np.clip(np.sin(ang * np.pi), 0, 1))
    ring = np.clip((width - np.abs(rr - S * 0.42)) / 2, 0, 1) * (ang < 0.93)
    ring *= 0.75 + 0.5 * (K.value_noise(S, S, 4, rng) - 0.5)
    img = K.composite(img, (30, 26, 22), np.clip(ring, 0, 1))
    man = K.swordsman_mask(600)
    canvas = np.zeros((S, S))
    K.place(canvas, man, S * 0.14, S * 0.10, 0.70)
    img = K.composite(img, (30, 26, 22), canvas)
    # 圆形裁切 + 透明
    alpha = K.disc(S, S, S / 2, S / 2, S * 0.49, 2)
    rgba = np.dstack([np.clip(img, 0, 255), alpha * 255]).astype(np.uint8)
    seal = K.seal_image('灵', 120, rng=rng)
    out = Image.fromarray(rgba, 'RGBA')
    out.alpha_composite(seal, (S - 150, S - 150))
    out = out.resize((256, 256), Image.LANCZOS)
    out.save(os.path.join(OUT, 'xia_avatar.png'), optimize=True)


def make_hero():
    """空状态插画：月下松间侠客（单色 alpha，界面里按主题着色）。"""
    w, h = 900, 760
    rng = np.random.default_rng(9)
    a = np.zeros((h, w))
    # 月（空心淡圈 + 内部淡墨）
    a = np.maximum(a, K.disc(h, w, w * 0.68, h * 0.26, w * 0.13, 2) * 0.12)
    ring = K.disc(h, w, w * 0.68, h * 0.26, w * 0.13, 2) - K.disc(h, w, w * 0.68, h * 0.26, w * 0.13 - 4, 2)
    a = np.maximum(a, np.clip(ring, 0, 1) * 0.5)
    # 山
    m1, _ = K.mountain_layer(h, w, h * 0.80, h * 0.20, 150, rng, [(0.3, h * 0.12, 0.12)], rough=0.8)
    a = np.maximum(a, m1 * 0.35)
    # 崖石
    im = Image.new('L', (w, h), 0)
    d = ImageDraw.Draw(im)
    top = K.noise1d(64, 12, 4, rng)
    pts = [(0, h)] + [(w * 0.64 * i / 63, h * (0.80 + 0.05 * abs(i / 63 - 0.45) * 2.2) - top[i] * h * 0.04) for i in range(64)] + [(w * 0.66, h)]
    d.polygon(pts, fill=255)
    rock = ndimage.gaussian_filter(np.asarray(im, float) / 255, 2.5) * (0.82 + 0.3 * (K.fbm(h, w, 70, 3, rng) - 0.5))
    a = np.maximum(a, np.clip(rock, 0, 1) * 0.92)
    # 松
    pine = K.pine_mask(int(w * 0.98), int(h * 0.5), rng, origin=(0.0, 0.35))
    K.place(a, pine * 0.9, -w * 0.02, h * 0.05)
    # 侠客
    man = K.swordsman_mask(700, facing=1)
    K.place(a, man, w * 0.20, h * 0.435, 0.42)
    # 鸟
    a = np.maximum(a, K.birds_mask(w, h, rng, 4, (0.55, 0.45, 0.3, 0.1), 14) * 0.8)
    K.save_alpha(np.clip(a, 0, 1), 'ink_hero.png', color=(0, 0, 0))


def make_brush():
    a = K.brush_stroke(1400, 120, np.random.default_rng(3))
    K.save_alpha(a, 'brush_stroke.png')
    # 竖向短笔（用于气泡侧边 / 竹简）
    b = K.brush_stroke(600, 70, np.random.default_rng(4))
    K.save_alpha(np.rot90(b), 'brush_vertical.png')


def make_texture():
    """可无缝平铺的宣纸纤维纹理（alpha）。"""
    S = 512
    rng = np.random.default_rng(1)
    f = np.zeros((S, S))
    n = 380
    for _ in range(n):
        y, x = rng.random() * S, rng.random() * S
        L = 6 + rng.random() * 34
        a = rng.random() * np.pi
        for t in range(int(L)):
            f[int(y + t * np.sin(a)) % S, int(x + t * np.cos(a)) % S] += 1
    f = ndimage.gaussian_filter(f, 0.7, mode='wrap')
    speck = ndimage.gaussian_filter(rng.random((S, S)), 1.0, mode='wrap')
    cloud = ndimage.gaussian_filter(rng.random((S, S)), 24, mode='wrap')
    cloud = (cloud - cloud.min()) / (cloud.max() - cloud.min())
    a = np.clip(f * 0.45, 0, 1) + np.clip((speck - 0.5) * 1.2, 0, 1) * 0.18 + cloud * 0.10
    K.save_alpha(np.clip(a, 0, 1), 'paper_grain.png', color=(70, 52, 34))


def make_icon():
    """自适应图标前景：朱砂印「灵犀」+ 水墨圆；背景：宣纸。"""
    S = 432
    rng = np.random.default_rng(2)
    bg = K.paper(S, S, (240, 232, 214), rng, strength=0.7)
    # 前景：墨圆 + 印
    fg = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    yy, xx = np.mgrid[0:S, 0:S].astype(float)
    ang = (np.arctan2(yy - S / 2, xx - S / 2) + np.pi) / (2 * np.pi)
    rr = np.sqrt((xx - S / 2) ** 2 + (yy - S / 2) ** 2)
    width = 16 * (0.35 + 0.65 * np.clip(np.sin(ang * np.pi), 0, 1))
    ring = np.clip((width - np.abs(rr - S * 0.30)) / 2, 0, 1) * (ang < 0.92)
    ring = (np.dstack([np.full((S, S), 34), np.full((S, S), 28), np.full((S, S), 24), np.clip(ring, 0, 1) * 255])).astype(np.uint8)
    fg.alpha_composite(Image.fromarray(ring, 'RGBA'))
    d = ImageDraw.Draw(fg)
    ft = ImageFont.truetype(K.FONT_BRUSH, 150)
    bb = d.textbbox((0, 0), '灵', font=ft)
    d.text(((S - (bb[2] - bb[0])) / 2 - bb[0], (S - (bb[3] - bb[1])) / 2 - bb[1] - 6), '灵', font=ft, fill=(30, 25, 22, 255))
    seal = K.seal_image('犀', 64, rng=rng)
    fg.alpha_composite(seal, (int(S * 0.60), int(S * 0.60)))
    fg.save(os.path.join(OUT, 'ic_launcher_fg.png'))
    Image.fromarray(bg.astype(np.uint8)).save(os.path.join(OUT, 'ic_launcher_bg.png'))
    # 旧版图标（合成）
    comp = Image.fromarray(bg.astype(np.uint8)).convert('RGBA')
    comp.alpha_composite(fg)
    mask = Image.new('L', (S, S), 0)
    ImageDraw.Draw(mask).rounded_rectangle([S * 0.17, S * 0.17, S * 0.83, S * 0.83], radius=S * 0.12, fill=255)
    comp = comp.crop((int(S * 0.17), int(S * 0.17), int(S * 0.83), int(S * 0.83)))
    m2 = mask.crop((int(S * 0.17), int(S * 0.17), int(S * 0.83), int(S * 0.83)))
    comp.putalpha(m2)
    comp.resize((192, 192), Image.LANCZOS).save(os.path.join(OUT, 'ic_dia_logo.png'))


if 'paper' in which: K.save_rgb(scene_paper(), 'bg_paper.webp')
if 'night' in which: K.save_rgb(scene_night(), 'bg_night.webp', 92)
if 'wuji' in which: K.save_rgb(scene_wuji(), 'bg_wuji.webp', 90)
if 'avatar' in which: make_avatar()
if 'hero' in which: make_hero()
if 'brush' in which: make_brush()
if 'texture' in which: make_texture()
if 'icon' in which: make_icon()
print('done', which)
