#!/bin/bash
# 灵犀 Dia 3.0 —— 一键把代码推到 GitHub（推上去后 GitHub 会自动打包 APK）
set -e
cd "$(dirname "$0")"
read -p "你的 GitHub 用户名: " USER
read -p "仓库名（默认 lingxi-dia）: " REPO
REPO=${REPO:-lingxi-dia}
[ -d .git ] || git init
git add -A
git commit -m "灵犀 3.0 水墨江湖 · 无极版" || true
git branch -M main
git remote remove origin 2>/dev/null || true
git remote add origin "https://github.com/$USER/$REPO.git"
git push -u origin main
echo ""
echo "✅ 已推送。打开 https://github.com/$USER/$REPO/actions 等待「Android 打包」变绿，然后在页面底部 Artifacts 下载 APK。"
