package com.dia.app

import com.dia.app.agent.ToolCallParser
import com.dia.app.files.OfficeXml
import com.dia.app.files.TextDecode
import com.dia.app.memory.MemoryRules
import com.dia.app.memory.MemoryText
import com.dia.app.web.HtmlText
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** 纯逻辑单元测试：./gradlew test */
class CoreLogicTest {

    @Test fun toolCallTag() {
        val raw = ToolCallParser.findRaw("<tool>{\"name\":\"web_search\",\"args\":{\"query\":\"北京 {天气}\"}}</tool>")
        assertEquals("{\"name\":\"web_search\",\"args\":{\"query\":\"北京 {天气}\"}}", raw?.json)
    }

    @Test fun toolCallVariants() {
        assertNotNull(ToolCallParser.findRaw("```json\n{\"tool\":\"translate\",\"params\":{\"text\":\"hi\"}}\n```"))
        assertNotNull(ToolCallParser.findRaw("<tool>{\"name\":\"remember\",\"args\":{\"content\":\"x\"}"))
        assertNull(ToolCallParser.findRaw("今天天气不错。"))
        assertNull(ToolCallParser.findRaw("{\"a\": 1}"))
        assertEquals("答案", ToolCallParser.visibleText("答案<to"))
    }

    @Test fun docxRoundTrip() {
        val doc = OfficeXml.docxCreate("甲方负责付款\n第二行 & <符号>")
        assertTrue(OfficeXml.docxText(doc).contains("第二行 & <符号>"))
        val (edited, n) = OfficeXml.docxReplace(doc, "甲方", "乙方")
        assertEquals(1, n)
        assertTrue(OfficeXml.docxText(edited).startsWith("乙方负责付款"))
        val appended = OfficeXml.docxAppend(edited, "追加")
        assertTrue(OfficeXml.docxText(appended).trimEnd().endsWith("追加"))
    }

    @Test fun textDecodeGbk() {
        assertEquals("中文", TextDecode.decode("中文".toByteArray(charset("GB18030"))))
        assertEquals("GB18030", TextDecode.detectCharsetName("中文".toByteArray(charset("GB18030"))))
    }

    @Test fun memoryRules() {
        val found = MemoryRules.extract("我叫小明。我对花生过敏。我喜欢什么颜色？").map { it.first }
        assertTrue(found.contains("用户名叫小明"))
        assertTrue(found.contains("用户对花生过敏"))
        assertTrue(found.none { it.contains("颜色") })
        assertTrue(MemoryText.similar("用户喜欢喝龙井茶", "用户喜欢喝龙井"))
    }

    @Test fun bingParse() {
        val html = "<li class=\"b_algo\"><h2><a href=\"https://example.com/a\">标题</a></h2><p>摘要</p></li>"
        val hits = HtmlText.parseBing(html)
        assertEquals(1, hits.size)
        assertEquals("https://example.com/a", hits[0].url)
    }
}
