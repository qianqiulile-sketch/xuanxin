package com.dia.app

import com.dia.app.agent.Calc
import com.dia.app.agent.DocTools
import com.dia.app.agent.ToolCallParser
import com.dia.app.files.MdBlock
import com.dia.app.files.Markdown
import com.dia.app.files.OfficeEdit
import com.dia.app.files.OfficeXml
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** 新增能力的纯逻辑测试：多工具调用解析、计算器、Markdown、Word/PPT/Excel 精细编辑。 */
class AgentLogicTest {

    @Test fun multipleToolCalls() {
        val out = "先查两件事\n<tool>{\"name\":\"web_search\",\"args\":{\"query\":\"A\"}}</tool>\n<tool>{\"name\":\"web_search\",\"args\":{\"query\":\"B\"}}</tool>"
        val all = ToolCallParser.findAll(out)
        assertEquals(2, all.size)
        assertTrue(all[1].json.contains("\"B\""))
        // 单个调用仍然兼容
        assertEquals(1, ToolCallParser.findAll("<tool>{\"name\":\"calc\",\"args\":{\"expr\":\"1+1\"}}</tool>").size)
        assertEquals(0, ToolCallParser.findAll("普通回答，没有工具。").size)
    }

    @Test fun calculator() {
        assertEquals("16", Calc.format(Calc.eval("(1+3)*4")))
        assertEquals("2.5", Calc.format(Calc.eval("10÷4")))
        assertEquals("1024", Calc.format(Calc.eval("2^10")))
        assertEquals("15", Calc.format(Calc.eval("300×5%")))
        assertEquals("3", Calc.format(Calc.eval("sqrt(9)")))
    }

    @Test fun markdownBlocks() {
        val b = Markdown.parse("# 标题\n正文**加粗**\n- 一\n- 二\n| a | b |\n|---|---|\n| 1 | 2 |\n3.5亿元不是列表")
        assertTrue(b[0] is MdBlock.Heading)
        assertEquals(2, b.count { it is MdBlock.Bullet })
        assertTrue(b.any { it is MdBlock.Table && it.rows.size == 2 })
        assertTrue(b.last() is MdBlock.Para)
        assertEquals("正文加粗", Markdown.plain("正文**加粗**"))
    }

    @Test fun docxParagraphOps() {
        val doc = OfficeEdit.docxCreateMarkdown("# 报告\n第一段\n\n第二段", "报告")
        val paras = OfficeEdit.docxParagraphs(doc).filter { it.isNotBlank() }
        assertEquals(listOf("报告", "第一段", "第二段"), paras)
        val all = OfficeEdit.docxParagraphs(doc)
        val i1 = all.indexOf("第一段")
        val (d2, n) = OfficeEdit.docxApply(doc, listOf(OfficeEdit.ParaOp("set", i1, "改过的第一段"), OfficeEdit.ParaOp("delete", all.indexOf("第二段"))))
        assertEquals(2, n)
        val text = OfficeXml.docxText(d2)
        assertTrue(text.contains("改过的第一段"))
        assertTrue(!text.contains("第二段"))
    }

    @Test fun pptxCreateEditDelete() {
        val deck = OfficeEdit.pptxCreate(OfficeEdit.parseSlides("# 封面\n副标题\n\n# 第一页\n- 要点A\n- 要点B\n\n# 第二页\n- C"))
        assertEquals(3, OfficeEdit.slideOrder(OfficeXml.unzip(deck)).size)
        val edited = OfficeEdit.pptxSetSlide(deck, 2, "新标题", listOf("新要点"))
        assertTrue(OfficeXml.pptxText(edited).contains("新要点"))
        val (added, pos) = OfficeEdit.pptxDuplicateSlide(edited, 3, "加的一页", listOf("X"), toEnd = true)
        assertEquals(4, pos)
        val removed = OfficeEdit.pptxDeleteSlide(added, 1)
        assertEquals(3, OfficeEdit.slideOrder(OfficeXml.unzip(removed)).size)
    }

    @Test fun xlsxCreateAndSetCells() {
        val x = OfficeEdit.xlsxCreate(OfficeEdit.parseSheets("| 名称 | 数量 |\n|---|---|\n| 甲 | 3 |"))
        val y = OfficeEdit.xlsxSetCells(x, null, mapOf("B3" to "5", "A3" to "乙", "C2" to "=B2*2"))
        val t = OfficeXml.xlsxText(y)
        assertTrue(t.contains("乙\t5"))
        assertEquals("AA", OfficeEdit.colLetters(27))
        assertEquals(28, OfficeEdit.colIndex("AB"))
    }

    @Test fun numberedRewriteParsing() {
        val m = DocTools.parseNumbered("[0] 第一段\n[3] 第二段\n继续第二段\n【5】第三段")
        assertEquals("第一段", m[0])
        assertEquals("第二段\n继续第二段", m[3])
        assertEquals("第三段", m[5])
    }
}
