package com.dia.app.ui.slate

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.BorderColor
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke as DrawStroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.AwaitPointerEventScope
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dia.app.slate.InkPoint
import com.dia.app.slate.NotebookPage
import com.dia.app.slate.PageBackground
import com.dia.app.slate.PenMode
import com.dia.app.slate.SlateState
import com.dia.app.slate.drawInkStroke
import com.dia.app.ui.theme.DiaSurface
import com.dia.app.ui.theme.DiaTextSecondary
import com.dia.app.ui.theme.DiaTextTertiary
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Coordinate system used by [PageCanvas]:
 *
 *   screen = origin + (pagePoint - pan) * pageScale
 *   pagePoint = pan + (screen - origin) / pageScale
 *
 * where:
 *   pageScale  = fitScale * state.zoom
 *   fitScale   = min(viewportW / pageW, viewportH / pageH) * 0.94
 *   originX/Y  = top-left of the drawn page (centered horizontally,
 *                pinned to top with a 16dp margin so the page indicator
 *                pill never overlaps the page).
 *
 * Both the renderer's `withTransform` and the pointer's inverse use the
 * SAME `pageScale`, so where the finger touches is exactly where the
 * ink lands at any zoom. Pan is clamped so the page never slides
 * fully off-screen.
 */
@Composable
fun PageCanvas(
    state: SlateState,
    page: NotebookPage,
    modifier: Modifier = Modifier,
) {
    var viewportSize by remember { mutableStateOf(Size.Zero) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0A0B11)),
        contentAlignment = Alignment.Center,
    ) {
        // viewportSize must be measured on the Canvas itself — NOT the
        // parent Box. If measured on the Box, any contentAlignment offset
        // between Box and Canvas causes the coordinate transform to be
        // wrong, making ink draw away from the finger.
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .onSizeChanged { viewportSize = Size(it.width.toFloat(), it.height.toFloat()) }
                .pointerInput(state, page.id) {
                    drawingGesture(state, page) { computePageLayout(viewportSize, page, state) }
                }
        ) {
            // Read live tick so the canvas re-runs on each new stroke point.
            @Suppress("UNUSED_VARIABLE")
            val tick = state.liveStrokeTick

            if (viewportSize == Size.Zero) return@Canvas
            val layout = computePageLayout(viewportSize, page, state)

            // Page paper + grid/rule.
            drawPagePaper(layout, page, state.pageBackground)

            // Strokes inside the page rect — clip in screen-space using
            // the actual drawn page rect, so out-of-bounds points (which
            // shouldn't happen, but might during zoom-in flicker) never
            // bleed onto the dark area.
            clipRect(
                left = layout.originX,
                top = layout.originY,
                right = layout.originX + layout.pageW * layout.pageScale,
                bottom = layout.originY + layout.pageH * layout.pageScale,
            ) {
                withTransform({
                    translate(left = layout.originX, top = layout.originY)
                    scale(scaleX = layout.pageScale, scaleY = layout.pageScale)
                    translate(left = -state.pan.x, top = -state.pan.y)
                }) {
                    for (s in page.strokes) drawInkStroke(s)
                    state.currentStroke?.let { drawInkStroke(it) }
                    state.currentAiStroke?.let { drawInkStroke(it) }
                    // Eraser visualisation: a circle on the cursor tip
                    // so the user can see what they're erasing.
                    state.eraserPos?.let { pos ->
                        if (state.penMode == PenMode.ERASER) {
                            drawCircle(
                                color = Color(0xFFFF8A80).copy(alpha = 0.18f),
                                radius = state.penWidth * 8f,
                                center = pos,
                            )
                            drawCircle(
                                color = Color(0xFFFF8A80).copy(alpha = 0.55f),
                                radius = state.penWidth * 8f,
                                center = pos,
                                style = DrawStroke(width = 1.5f),
                            )
                        }
                    }
                }
            }

            drawPageBorder(layout)
        }
    }
}

/**
 * Pan + pinch-zoom logic. Single finger = draw / erase. Two+ fingers =
 * pan + pinch-zoom. The transform is consistent so the touched
 * canvas-space point stays pinned under the finger average.
 */
private suspend fun PointerInputScope.drawingGesture(
    state: SlateState,
    page: NotebookPage,
    layoutProvider: () -> PageLayout,
) {
    awaitEachGesture {
        val first = awaitFirstDown(requireUnconsumed = false)

        // If a second finger is already down, switch to pan/zoom.
        if (currentEvent.changes.count { it.pressed } > 1) {
            state.eraserPos = null
            handlePanZoom(state, layoutProvider)
            return@awaitEachGesture
        }

        val pp = clampToPage(screenToPage(first.position, layoutProvider(), state), page)
        if (state.penMode == PenMode.ERASER) {
            // Eraser: live-erase as the user drags, no stroke build-up.
            state.eraserPos = pp
            page.eraseAtPoint(pp, state.eraserRadius())
            first.consume()
        } else {
            state.beginStroke(InkPoint(pp.x, pp.y, first.pressure.coerceIn(0.1f, 1f)))
            first.consume()
        }

        while (true) {
            val event = awaitPointerEvent(PointerEventPass.Main)
            if (event.changes.count { it.pressed } > 1) {
                // Switching to pan/zoom mid-gesture: drop the in-flight stroke.
                state.cancelStroke()
                state.eraserPos = null
                handlePanZoom(state, layoutProvider)
                return@awaitEachGesture
            }
            val change = event.changes.first()
            if (!change.pressed) {
                if (state.penMode == PenMode.ERASER) {
                    state.eraserPos = null
                } else {
                    state.endStroke()
                }
                break
            }
            val ppNow = clampToPage(screenToPage(change.position, layoutProvider(), state), page)
            if (state.penMode == PenMode.ERASER) {
                state.eraserPos = ppNow
                page.eraseAtPoint(ppNow, state.eraserRadius())
                state.bumpLiveTick()
            } else {
                state.extendStroke(InkPoint(ppNow.x, ppNow.y, change.pressure.coerceIn(0.1f, 1f)))
            }
            change.consume()
        }
    }
}

private suspend fun AwaitPointerEventScope.handlePanZoom(
    state: SlateState,
    layoutProvider: () -> PageLayout,
) {
    while (true) {
        val event = awaitPointerEvent(PointerEventPass.Main)
        val pressed = event.changes.filter { it.pressed }
        if (pressed.size < 2) return

        val a = pressed[0]; val b = pressed[1]
        val prevAvg = (a.previousPosition + b.previousPosition) / 2f
        val curAvg = (a.position + b.position) / 2f
        val prevDist = distance(a.previousPosition, b.previousPosition).coerceAtLeast(1f)
        val curDist = distance(a.position, b.position).coerceAtLeast(1f)
        val zoomFactor = curDist / prevDist

        val layout = layoutProvider()

        if (abs(zoomFactor - 1f) > 0.001f) {
            // Anchor the page point under the focal point during pinch.
            val focalPageBefore = screenToPage(curAvg, layout, state)
            val newZoom = (state.zoom * zoomFactor).coerceIn(0.5f, 4f)
            state.zoom = newZoom
            val newLayout = layout.copy(zoom = newZoom)
            state.pan = Offset(
                focalPageBefore.x - (curAvg.x - newLayout.originX) / newLayout.pageScale,
                focalPageBefore.y - (curAvg.y - newLayout.originY) / newLayout.pageScale,
            )
        } else {
            val dx = curAvg.x - prevAvg.x
            val dy = curAvg.y - prevAvg.y
            state.pan = Offset(
                state.pan.x - dx / layout.pageScale,
                state.pan.y - dy / layout.pageScale,
            )
        }
        clampPan(state, layoutProvider())
        a.consume(); b.consume()
    }
}

/* ─── Layout & coord maths ─── */

internal data class PageLayout(
    val viewportW: Float,
    val viewportH: Float,
    val pageW: Float,
    val pageH: Float,
    val fitScale: Float,
    val zoom: Float,
) {
    val pageScale: Float get() = fitScale * zoom
    val drawnW: Float get() = pageW * pageScale
    val drawnH: Float get() = pageH * pageScale
    val originX: Float get() = (viewportW - drawnW) / 2f
    val originY: Float get() = (viewportH - drawnH) / 2f
}

private fun computePageLayout(viewport: Size, page: NotebookPage, state: SlateState): PageLayout {
    val padFactor = 0.94f
    val fitScale = min(viewport.width / page.width, viewport.height / page.height) * padFactor
    return PageLayout(
        viewportW = viewport.width,
        viewportH = viewport.height,
        pageW = page.width,
        pageH = page.height,
        fitScale = fitScale,
        zoom = state.zoom,
    )
}

private fun screenToPage(screen: Offset, layout: PageLayout, state: SlateState): Offset {
    val px = state.pan.x + (screen.x - layout.originX) / layout.pageScale
    val py = state.pan.y + (screen.y - layout.originY) / layout.pageScale
    return Offset(px, py)
}

/** Snap a page-space point to lie strictly within the page rect. */
private fun clampToPage(p: Offset, page: NotebookPage): Offset {
    val x = p.x.coerceIn(0f, page.width)
    val y = p.y.coerceIn(0f, page.height)
    return Offset(x, y)
}

/**
 * Bound pan so the page can't be dragged off-screen. At zoom <= 1 we
 * lock pan to (0, 0) — the page is fit to the viewport, nothing to pan.
 * At zoom > 1 we allow panning within the page rect itself, never
 * showing the dark background instead of paper unless the page edge is
 * already on screen.
 */
private fun clampPan(state: SlateState, layout: PageLayout) {
    if (state.zoom <= 1f) {
        state.pan = Offset.Zero
        return
    }
    // Visible viewport in page-space.
    val visiblePageW = layout.viewportW / layout.pageScale
    val visiblePageH = layout.viewportH / layout.pageScale
    val maxPanX = max(0f, layout.pageW - visiblePageW)
    val maxPanY = max(0f, layout.pageH - visiblePageH)
    state.pan = Offset(
        state.pan.x.coerceIn(0f, maxPanX),
        state.pan.y.coerceIn(0f, maxPanY),
    )
}

private fun SlateState.eraserRadius(): Float = penWidth * 8f

private fun distance(a: Offset, b: Offset): Float {
    val dx = a.x - b.x; val dy = a.y - b.y
    return sqrt(dx * dx + dy * dy)
}

/* ─── Rendering helpers ─── */

private fun DrawScope.drawPagePaper(layout: PageLayout, page: NotebookPage, bg: PageBackground) {
    val left = layout.originX
    val top = layout.originY
    val drawnW = layout.drawnW
    val drawnH = layout.drawnH

    // Drop shadow under the page.
    drawRect(
        color = Color.Black.copy(alpha = 0.45f),
        topLeft = Offset(left + 4f, top + 6f),
        size = androidx.compose.ui.geometry.Size(drawnW, drawnH),
    )
    drawRect(
        color = SlateState.PaperColor,
        topLeft = Offset(left, top),
        size = androidx.compose.ui.geometry.Size(drawnW, drawnH),
    )

    if (bg == PageBackground.PLAIN) return

    val rule = when (bg) {
        PageBackground.RULED -> 64f
        PageBackground.GRID -> 56f
        PageBackground.DOTS -> 48f
        else -> 0f
    } * layout.pageScale

    when (bg) {
        PageBackground.RULED -> {
            var y = top + rule
            while (y < top + drawnH) {
                drawLine(
                    color = SlateState.PaperRule.copy(alpha = 0.55f),
                    start = Offset(left + 8f, y),
                    end = Offset(left + drawnW - 8f, y),
                    strokeWidth = 1f,
                )
                y += rule
            }
        }
        PageBackground.GRID -> {
            var x = left + rule
            while (x < left + drawnW) {
                drawLine(SlateState.PaperRule.copy(alpha = 0.4f), Offset(x, top), Offset(x, top + drawnH), 1f)
                x += rule
            }
            var y = top + rule
            while (y < top + drawnH) {
                drawLine(SlateState.PaperRule.copy(alpha = 0.4f), Offset(left, y), Offset(left + drawnW, y), 1f)
                y += rule
            }
        }
        PageBackground.DOTS -> {
            var x = left + rule
            while (x < left + drawnW) {
                var y = top + rule
                while (y < top + drawnH) {
                    drawCircle(
                        SlateState.PaperRule.copy(alpha = 0.55f),
                        radius = 1.4f,
                        center = Offset(x, y),
                    )
                    y += rule
                }
                x += rule
            }
        }
        PageBackground.PLAIN -> {}
    }
}

private fun DrawScope.drawPageBorder(layout: PageLayout) {
    val left = layout.originX
    val top = layout.originY
    drawRect(
        color = Color.Black.copy(alpha = 0.25f),
        topLeft = Offset(left, top),
        size = androidx.compose.ui.geometry.Size(layout.drawnW, layout.drawnH),
        style = DrawStroke(width = 1f),
    )
}

/* ─── Toolbar ─── */

@Composable
fun SlateToolbar(state: SlateState) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(DiaSurface)
            .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(20.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        // Row 1: tools — pen / highlighter / eraser
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            ToolButton(Icons.Rounded.Edit, state.penMode == PenMode.PEN, state.penColor) {
                state.penMode = PenMode.PEN
            }
            ToolButton(Icons.Rounded.BorderColor, state.penMode == PenMode.HIGHLIGHTER, Color(0xFF5E97FF)) {
                state.penMode = PenMode.HIGHLIGHTER
            }
            ToolButton(Icons.Rounded.AutoFixHigh, state.penMode == PenMode.ERASER, Color(0xFFFF8A80)) {
                state.penMode = PenMode.ERASER
            }
            Spacer(Modifier.weight(1f))
            // Stroke width picker on the right.
            for (w in PenWidths) WidthChip(state, w)
        }

        // Row 2: color swatches — only relevant when drawing.
        if (state.penMode != PenMode.ERASER) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                for (c in PenColors) ColorSwatch(state, c)
            }
        }
    }
}

private val PenColors = listOf(
    Color(0xFF1F2230), // dark — default ink on paper
    Color(0xFFC53030),
    Color(0xFF1F6FB6),
    Color(0xFF2E7D32),
    Color(0xFFD68F00),
)

private val PenWidths = listOf(2f, 3.5f, 5f, 7f)

@Composable
private fun ToolButton(icon: ImageVector, selected: Boolean, tint: Color, onClick: () -> Unit) {
    val bg = if (selected) tint.copy(alpha = 0.18f) else Color.Transparent
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(bg),
    ) {
        Icon(icon, null, tint = if (selected) tint else DiaTextSecondary, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun ColorSwatch(state: SlateState, color: Color) {
    val selected = state.penColor == color && state.penMode != PenMode.HIGHLIGHTER
    Box(
        modifier = Modifier
            .size(24.dp)
            .clip(CircleShape)
            .background(color)
            .border(
                if (selected) 2.dp else 1.dp,
                if (selected) Color.White else Color.White.copy(alpha = 0.15f),
                CircleShape,
            ),
    ) {
        IconButton(
            onClick = {
                state.penColor = color
                if (state.penMode == PenMode.ERASER) state.penMode = PenMode.PEN
            },
            modifier = Modifier.fillMaxSize(),
        ) {}
    }
}

@Composable
private fun WidthChip(state: SlateState, w: Float) {
    val selected = abs(state.penWidth - w) < 0.1f
    Box(
        modifier = Modifier
            .size(28.dp)
            .clip(CircleShape)
            .background(if (selected) Color.White.copy(alpha = 0.08f) else Color.Transparent),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .size((4f + w * 1.4f).dp)
                .clip(CircleShape)
                .background(if (selected) state.penColor else DiaTextTertiary),
        )
        IconButton(onClick = { state.penWidth = w }, modifier = Modifier.fillMaxSize()) {}
    }
}

/** Page indicator pill: "3 / 12". */
@Composable
fun PageIndicator(currentIndex: Int, total: Int, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(Color.Black.copy(alpha = 0.55f))
            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(50))
            .padding(horizontal = 14.dp, vertical = 6.dp),
    ) {
        Text(
            "${currentIndex + 1} / $total",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
            color = Color.White.copy(alpha = 0.9f),
        )
    }
}
