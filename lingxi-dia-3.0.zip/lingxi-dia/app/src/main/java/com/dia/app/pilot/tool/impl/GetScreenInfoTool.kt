package com.dia.app.pilot.tool.impl

import com.dia.app.pilot.tool.BaseTool
import com.dia.app.pilot.tool.ToolParameter
import com.dia.app.pilot.tool.ToolResult

class GetScreenInfoTool : BaseTool() {
    override fun getName(): String = "get_screen_info"

    override fun getDescription(): String =
        "Get the current screen UI tree. Each element has a node ID like [n3] for tap_node."

    override fun getParameters(): List<ToolParameter> = emptyList()

    override fun execute(params: Map<String, Any>): ToolResult {
        return try {
            val service = requireAccessibilityService() ?: return ToolResult.error("Accessibility service is not running")
            val tree = service.getScreenTree() ?: return ToolResult.error("No active window")
            ToolResult.success(tree)
        } catch (e: Exception) {
            ToolResult.error("Screen capture error: ${e.message}")
        }
    }
}
