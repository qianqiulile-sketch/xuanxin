package com.dia.app.pilot.tool.impl

import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import com.dia.app.pilot.tool.BaseTool
import com.dia.app.pilot.tool.ToolParameter
import com.dia.app.pilot.tool.ToolResult
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Answers device queries without opening Settings.
 * Categories: battery, wifi, storage, device, time.
 */
class GetDeviceInfoTool : BaseTool() {
    override fun getName(): String = "get_device_info"

    override fun getDescription(): String =
        "Read device info directly. category=battery|wifi|storage|device|time"

    override fun getParameters(): List<ToolParameter> = listOf(
        ToolParameter("category", "string", "One of: battery, wifi, storage, device, time", true),
    )

    override fun execute(params: Map<String, Any>): ToolResult {
        return try {
            val ctx = requireAccessibilityService()?.applicationContext
                ?: return ToolResult.error("Accessibility service is not running")

            when (requireString(params, "category").lowercase()) {
                "battery" -> ToolResult.success(readBattery(ctx))
                "wifi" -> ToolResult.success(readWifi(ctx))
                "storage" -> ToolResult.success(readStorage())
                "device" -> ToolResult.success(readDevice())
                "time" -> ToolResult.success(readTime())
                else -> ToolResult.error("Unsupported category")
            }
        } catch (e: Exception) {
            ToolResult.error("Device info error: ${e.message}")
        }
    }

    private fun readBattery(ctx: Context): String {
        return try {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            val statusIntent = ctx.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val plugged = statusIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1
            val charging = plugged != 0
            "Battery: $level% ${if (charging) "(charging)" else "(on battery)"}"
        } catch (e: Exception) {
            "Battery: unavailable (${e.message})"
        }
    }

    private fun readWifi(ctx: Context): String {
        return try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val enabled = wm.isWifiEnabled
            "Wifi: ${if (enabled) "on" else "off"}"
        } catch (e: Exception) {
            "Wifi: unavailable (${e.message})"
        }
    }

    private fun readStorage(): String {
        return try {
            val s = StatFs(Environment.getDataDirectory().path)
            val total = (s.blockCountLong * s.blockSizeLong) / (1024L * 1024L * 1024L)
            val free = (s.availableBlocksLong * s.blockSizeLong) / (1024L * 1024L * 1024L)
            "Storage: $free GB free of $total GB"
        } catch (e: Exception) {
            "Storage: unavailable (${e.message})"
        }
    }

    private fun readDevice(): String {
        return "Device: ${Build.BRAND} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
    }

    private fun readTime(): String {
        val fmt = SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss", Locale.getDefault())
        return "Time: ${fmt.format(Date())}"
    }
}
