package com.dia.app.ui.pilot

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dia.app.DiaAccessibilityService
import com.dia.app.pilot.PilotAgent
import com.dia.app.pilot.PilotLogEntry
import com.dia.app.ui.theme.DiaBackground
import com.dia.app.ui.theme.inkPageBackground
import com.dia.app.ui.theme.DiaPilotColor
import com.dia.app.ui.theme.DiaSurface
import com.dia.app.ui.theme.DiaTextPrimary
import com.dia.app.ui.theme.DiaTextSecondary
import com.dia.app.ui.theme.DiaTextTertiary
import kotlinx.coroutines.launch

@Composable
fun PilotScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var taskText by remember { mutableStateOf("") }
    val scrollState = rememberScrollState()
    val scope = rememberCoroutineScope()

    // Attach app context so the agent can start its foreground service later.
    LaunchedEffect(Unit) { PilotAgent.attach(context) }

    val state by PilotAgent.state.collectAsState()
    val logEntries by PilotAgent.log.collectAsState()
    val isRunning = state.running

    // Auto-scroll on new log entries
    LaunchedEffect(logEntries.size) {
        scope.launch { scrollState.animateScrollTo(scrollState.maxValue) }
    }

    val a11yReady = DiaAccessibilityService.isRunning()

    // Voice input — same pattern as GuideScreen.
    var isListening by remember { mutableStateOf(false) }
    val speechRecognizer = remember {
        if (android.speech.SpeechRecognizer.isRecognitionAvailable(context))
            android.speech.SpeechRecognizer.createSpeechRecognizer(context)
        else null
    }
    val recognizerIntent = remember {
        android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM,
            )
            putExtra(
                android.speech.RecognizerIntent.EXTRA_LANGUAGE,
                "zh-CN",
            )
        }
    }
    DisposableEffect(Unit) {
        speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(p: android.os.Bundle?) { isListening = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(p: Float) {}
            override fun onBufferReceived(p: ByteArray?) {}
            override fun onEndOfSpeech() { isListening = false }
            override fun onError(e: Int) { isListening = false }
            override fun onResults(results: android.os.Bundle?) {
                isListening = false
                val text = results?.getStringArrayList(
                    android.speech.SpeechRecognizer.RESULTS_RECOGNITION
                )?.firstOrNull()
                if (!text.isNullOrBlank()) {
                    taskText = text
                }
            }
            override fun onPartialResults(p: android.os.Bundle?) {}
            override fun onEvent(p: Int, q: android.os.Bundle?) {}
        })
        onDispose { speechRecognizer?.destroy() }
    }

    // Auto-start listening when screen opens if preference is enabled.
    LaunchedEffect(Unit) {
        if (com.dia.app.prefs.DiaPrefs.autoListen.value) {
            kotlinx.coroutines.delay(500)
            try { speechRecognizer?.startListening(recognizerIntent) } catch (_: Exception) {}
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .inkPageBackground()
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // ── Header ──
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回", tint = DiaTextSecondary)
            }
            Spacer(modifier = Modifier.width(6.dp))
            Column {
                Text("Pilot", style = MaterialTheme.typography.titleLarge, color = DiaTextPrimary)
                Text("你的手机自动驾驶", style = MaterialTheme.typography.bodySmall, color = DiaTextSecondary)
            }
            Spacer(modifier = Modifier.weight(1f))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (isRunning) DiaPilotColor.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.06f))
                    .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    if (isRunning) "运行中" else "空闲",
                    color = if (isRunning) DiaPilotColor else DiaTextSecondary,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }

        // ── Accessibility Warning ──
        if (!a11yReady) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DiaSurface, RoundedCornerShape(16.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Text("需要无障碍权限", color = DiaTextPrimary, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(6.dp))
                Text("请在无障碍设置中启用灵犀，以便 Pilot 代你点击和输入。", color = DiaTextSecondary)
                Spacer(modifier = Modifier.height(12.dp))
                Row {
                    IconButton(
                        onClick = {
                            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(intent)
                        },
                        modifier = Modifier
                            .size(42.dp)
                            .background(DiaPilotColor, CircleShape)
                    ) {
                        Icon(Icons.Rounded.PlayArrow, "启用", tint = Color.Black)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("打开设置", color = DiaTextSecondary, modifier = Modifier.align(Alignment.CenterVertically))
                }
            }
        }

        // ── Task Input ──
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(DiaSurface, RoundedCornerShape(16.dp))
                .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(16.dp))
                .padding(14.dp)
        ) {
            Text("任务", color = DiaTextSecondary, style = MaterialTheme.typography.labelSmall)
            Spacer(modifier = Modifier.height(6.dp))
            Box(modifier = Modifier.fillMaxWidth()) {
                if (taskText.isEmpty()) {
                    Text(
                        "例如：打开微信并发送一条消息",
                        color = DiaTextTertiary,
                        fontSize = 13.sp
                    )
                }
                BasicTextField(
                    value = taskText,
                    onValueChange = { taskText = it },
                    textStyle = TextStyle(color = DiaTextPrimary, fontSize = 15.sp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 40.dp, max = 120.dp),
                    maxLines = 5,
                    singleLine = false,
                )
            }
        }

        // ── Controls ──
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = {
                    if (!isRunning && taskText.isNotBlank()) {
                        PilotAgent.start(taskText.trim())
                    }
                },
                enabled = !isRunning && taskText.isNotBlank(),
                modifier = Modifier
                    .size(56.dp)
                    .background(if (isRunning) DiaSurface else DiaPilotColor, CircleShape)
            ) {
                Icon(Icons.Rounded.PlayArrow, "开始", tint = if (isRunning) DiaTextTertiary else Color.Black)
            }

            // Voice input — speak your task.
            IconButton(
                onClick = {
                    if (!isListening && !isRunning) {
                        try { speechRecognizer?.startListening(recognizerIntent) } catch (_: Exception) {}
                    } else if (isListening) {
                        try { speechRecognizer?.stopListening() } catch (_: Exception) {}
                    }
                },
                enabled = !isRunning,
                modifier = Modifier
                    .size(56.dp)
                    .background(
                        if (isListening) DiaPilotColor.copy(alpha = 0.85f)
                        else Color.White.copy(alpha = 0.06f),
                        CircleShape,
                    )
                    .border(
                        1.dp,
                        if (isListening) DiaPilotColor else Color.White.copy(alpha = 0.10f),
                        CircleShape,
                    ),
            ) {
                Icon(
                    Icons.Rounded.Mic,
                    contentDescription = if (isListening) "聆听中… 点击停止" else "说出你的任务",
                    tint = if (isListening) Color.Black else DiaTextPrimary,
                )
            }

            IconButton(
                onClick = { if (isRunning) PilotAgent.stop() },
                enabled = isRunning,
                modifier = Modifier
                    .size(56.dp)
                    .background(if (isRunning) Color(0xFF2A2A3A) else DiaSurface, CircleShape)
            ) {
                Icon(Icons.Rounded.Stop, "停止", tint = if (isRunning) DiaTextPrimary else DiaTextTertiary)
            }

            // Repeat last task button
            if (!isRunning && PilotAgent.lastTask != null) {
                IconButton(
                    onClick = { PilotAgent.repeatLast() },
                    modifier = Modifier
                        .size(56.dp)
                        .background(Color.White.copy(alpha = 0.06f), CircleShape)
                        .border(1.dp, Color.White.copy(alpha = 0.10f), CircleShape)
                ) {
                    Icon(Icons.Rounded.Replay, "重复上一个任务", tint = DiaTextPrimary)
                }
            }

            Spacer(modifier = Modifier.weight(1f))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White.copy(alpha = 0.05f))
                    .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text(
                    text = if (isRunning) "第 ${state.stepIndex} 步 · ${state.lastMessage.take(24)}" else "就绪",
                    color = DiaTextSecondary,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }

        // ── Activity Log ──
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(DiaSurface, RoundedCornerShape(16.dp))
                .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(16.dp))
                .padding(14.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("活动记录", color = DiaTextSecondary, style = MaterialTheme.typography.labelSmall)
            Spacer(modifier = Modifier.height(4.dp))
            if (logEntries.isEmpty()) {
                Text("Pilot 日志将显示在这里", color = DiaTextTertiary)
            } else {
                logEntries.forEach { entry ->
                    val color = when (entry.kind) {
                        PilotLogEntry.Kind.FINISHED -> Color(0xFF81C784)
                        PilotLogEntry.Kind.FAILED -> Color(0xFFE57373)
                        PilotLogEntry.Kind.TOOL_CALL -> DiaPilotColor
                        PilotLogEntry.Kind.TOOL_RESULT -> DiaTextSecondary
                        else -> DiaTextPrimary
                    }
                    Text(entry.text, color = color, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
