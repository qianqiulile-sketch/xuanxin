package com.dia.app.pilot.tool

data class ToolParameter(
    val name: String,
    val type: String,
    val description: String,
    val required: Boolean,
)
