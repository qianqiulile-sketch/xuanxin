package com.dia.app.agent

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.dia.app.DiaAccessibilityService
import com.dia.app.files.FileManager
import com.dia.app.imagegen.ImageGen
import com.dia.app.llm.LlmGateway
import com.dia.app.memory.MemoryStore
import com.dia.app.pilot.PilotAgent
import com.dia.app.pilot.PilotEvent
import com.dia.app.prefs.DiaSettings
import com.dia.app.web.WebDownloader
import com.dia.app.web.WebReader
import com.dia.app.web.WebSearch
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject

/** 一个工具的说明（会写进系统提示词）。 */
data class ToolSpec(
    val name: String,
    val title: String,
    val args: String,
    val desc: String,
    val needsConfirm: Boolean = false,
    /** core / doc / phone / home / app：按需把相关的工具组放进提示词，节省上下文 */
    val group: String = "core",
    /** 只读、可并行执行（如搜索、读网页） */
    val readOnly: Boolean = false,
)

/** 工具执行结果。 */
data class ToolOutcome(
    /** 给模型看的结果 */
    val forModel: String,
    /** 卡片上显示的结果（可展开） */
    val display: String = forModel,
    val ok: Boolean = true,
    /** 结果已直接展示给用户（例如长篇译文），模型只需简单收尾 */
    val shownToUser: Boolean = false,
    /** 生成的图片路径 */
    val imagePath: String? = null,
    /** 需要模型进一步“看”的图片（如扫描版 PDF 页面） */
    val images: List<Bitmap> = emptyList(),
)

/** 工具执行时与界面交互的接口（由 ChatController 实现）。 */
interface ToolHost {
    val context: Context
    /** 弹出确认卡片，等待用户点「同意 / 拒绝」。 */
    suspend fun confirm(title: String, detail: String): Boolean
    /** 更新当前工具卡片的进度文字。 */
    fun progress(text: String)
    /** 需要把灵犀退到后台（例如框选屏幕翻译）。 */
    fun moveAppToBack()
    /** 是否处于无极模式（工具据此放宽超时等）。 */
    val wuji: Boolean get() = DiaSettings.wujiMode.value
}

object AgentTools {

    private const val TAG = "AgentTools"

    val ALL: List<ToolSpec> = listOf(
        // ── 核心 ──
        ToolSpec("web_search", "联网搜索", "{\"query\":\"搜索词\"}", "搜索互联网获取最新信息（新闻、价格、天气、百科、教程等），可换关键词多次搜索", readOnly = true),
        ToolSpec("read_webpage", "读取网页", "{\"url\":\"网址\"}", "打开网页读取正文", readOnly = true),
        ToolSpec("step_think", "分步思考", "{\"question\":\"复杂问题\"}", "把复杂问题拆成若干小问题，逐个检索研究后综合出结论（慢但深入）", readOnly = true),
        ToolSpec("calc", "计算", "{\"expr\":\"(12.5+3)*4\"}", "精确计算数学表达式，凡是算数都用它", readOnly = true),
        ToolSpec("read_file", "读取文件", "{\"file\":\"f1\",\"offset\":0}", "读取文件内容（Word/PPT/Excel/PDF/文本），offset 继续往后读", readOnly = true),
        ToolSpec("create_file", "新建文件", "{\"name\":\"文件名\",\"format\":\"docx|pptx|xlsx|pdf|md|txt|html|csv\",\"content\":\"Markdown内容\"}",
            "新建文件到「下载/Dia」。Word/PDF 写 Markdown（# 标题、- 列表、| 表格 |）；PPT 用「# 页标题」分页、「- 要点」；Excel 写表格或 CSV，多表用「## 表名」分隔"),
        ToolSpec("edit_file", "修改文件", "{\"file\":\"f1\",\"action\":\"…\"}",
            "修改文件（自动备份）。通用：replace{find,text}、append{text}、rewrite{text}；Word 按段：set_paragraph/insert_after/insert_before/delete_paragraph{index,text}；" +
                "PPT：set_slide/add_slide/delete_slide{slide,title,body:[要点]}；Excel：set_cells{sheet,cells:{\"B3\":\"120\",\"C3\":\"=B3*2\"}}、append_rows{rows:[[…]]}", needsConfirm = true),
        ToolSpec("rewrite_file", "AI 改写文档", "{\"file\":\"f1\",\"instruction\":\"改写要求\",\"save_as\":false}",
            "整篇改写 / 润色 / 扩写 / 精简 / 改语气 / 翻译，保留原有排版格式（PDF 会生成新 PDF；save_as=true 另存副本）", needsConfirm = true),
        ToolSpec("translate", "翻译", "{\"text\":\"内容\",\"to\":\"英文\"}", "翻译文字；{\"file\":\"f1\",\"to\":\"英文\"} 翻译整份文件并保留格式"),
        ToolSpec("generate_image", "生成图片", "{\"prompt\":\"画面描述\",\"size\":\"1024x1024\"}", "用生图 AI 画图"),
        ToolSpec("remember", "写入记忆", "{\"content\":\"要记住的事\",\"category\":\"偏好\"}", "把关于用户的重要信息记到长期记忆"),
        ToolSpec("recall", "查询记忆", "{\"query\":\"关键词\"}", "查找长期记忆里与关键词有关的内容", readOnly = true),
        // ── 文档 ──
        ToolSpec("doc_outline", "文档结构", "{\"file\":\"f1\"}", "查看文档结构：Word 段落编号、PPT 每页标题正文、Excel 单元格、PDF 每页，精确修改前先看", group = "doc", readOnly = true),
        ToolSpec("list_files", "浏览目录", "{\"dir\":\"Download\"}", "列出手机某个目录里的文件（路径可直接作 file 使用）", group = "doc", readOnly = true),
        ToolSpec("pdf_tool", "PDF 工具", "{\"action\":\"merge|extract|delete_pages|rotate|info|to_word|to_text\",\"file\":\"f1\",\"files\":[\"f1\",\"f2\"],\"pages\":\"1-3,5\"}",
            "PDF 合并、提取页、删页、旋转、查看信息、转 Word / 文本", group = "doc"),
        ToolSpec("convert_file", "格式转换", "{\"file\":\"f1\",\"to\":\"docx|pdf|md|txt|pptx|xlsx\"}", "把文档转换成其它格式（另存新文件）", group = "doc"),
        ToolSpec("restore_file", "还原文件", "{\"file\":\"f1\"}", "把文件还原到最近一次修改前的备份", needsConfirm = true, group = "doc"),
        ToolSpec("download", "下载文件", "{\"url\":\"文件网址\",\"filename\":\"可选文件名\"}", "把网上的文件下载到「下载/Dia」", needsConfirm = true, group = "doc"),
        // ── 手机 ──
        ToolSpec("open_app", "打开应用", "{\"name\":\"应用名\"}", "打开手机上的应用", group = "phone"),
        ToolSpec("phone_task", "操控手机", "{\"task\":\"任务描述\"}", "自动连续操作手机完成一整件事（打开应用、点击、输入、搜索…），如“打开微信给张三发消息说晚点到”", needsConfirm = true, group = "phone"),
        ToolSpec("phone_action", "手机操作", "{\"action\":\"tap|long_press|swipe|scroll_find|type|key|back|home|search|wait\",\"text\":\"…\",\"node_id\":\"n3\",\"direction\":\"up\"}",
            "单步操作屏幕（点文字/节点/坐标、滑动、输入、按键、应用内搜索），返回操作后的屏幕", group = "phone"),
        ToolSpec("read_screen", "读取屏幕", "{}", "读取当前屏幕上的文字和可点击节点", group = "phone", readOnly = true),
        ToolSpec("look_screen", "看屏幕", "{\"question\":\"要看什么\"}", "截屏后用视觉理解屏幕（图片、游戏、视频画面）", group = "phone", readOnly = true),
        ToolSpec("notifications", "读取通知", "{}", "读取通知栏里的消息", group = "phone", readOnly = true),
        ToolSpec("clipboard", "剪贴板", "{\"action\":\"get|set\",\"text\":\"…\"}", "读取或写入剪贴板", group = "phone"),
        ToolSpec("device_info", "设备信息", "{\"category\":\"battery|wifi|storage|device|time|all\"}", "电量、网络、存储、机型、时间", group = "phone", readOnly = true),
        ToolSpec("list_apps", "应用列表", "{\"keyword\":\"可选\"}", "列出已安装的应用", group = "phone", readOnly = true),
        ToolSpec("contacts", "通讯录", "{\"query\":\"姓名\"}", "查询通讯录里的号码", group = "phone", readOnly = true),
        ToolSpec("call_phone", "打电话", "{\"contact\":\"姓名或号码\"}", "拨打电话", needsConfirm = true, group = "phone"),
        ToolSpec("send_message", "发消息", "{\"contact\":\"姓名\",\"message\":\"内容\",\"app\":\"微信\"}", "用微信 / 短信等给联系人发消息", needsConfirm = true, group = "phone"),
        ToolSpec("open_url", "打开网址", "{\"url\":\"网址\"}", "用浏览器打开网址；{\"query\":\"词\"} 用浏览器搜索", group = "phone"),
        ToolSpec("guide", "屏幕引导", "{\"question\":\"想做什么\"}", "在屏幕上一步步指引用户自己操作某个应用", group = "phone"),
        ToolSpec("translate_screen", "翻译屏幕", "{}", "让用户在屏幕上框选区域进行翻译（会切到后台）", group = "phone"),
        // ── 智能家居 ──
        ToolSpec("smart_home", "智能家居", "{\"action\":\"list|state|call\",\"domain\":\"light\",\"service\":\"turn_on\",\"entity_id\":\"light.living_room\"}",
            "控制 Home Assistant 里的灯、空调、开关等", group = "home"),
        // ── 灵犀自身 ──
        ToolSpec("open_page", "打开功能页", "{\"page\":\"lens|slate|home|pilot|guide|settings|model|bubble\"}", "打开灵犀的功能页：实时镜头、手写板、智能家居、设置等", group = "app"),
        ToolSpec("set_theme", "切换主题", "{\"mode\":\"paper|ink|wuji\"}", "切换界面主题：宣纸山水 / 江湖夜色 / 无极墨金", group = "app"),
        ToolSpec("set_background", "更换背景", "{\"prompt\":\"画面\"}", "用 AI 生成水墨风对话背景；{\"image\":\"f1\"} 用图片做背景；{\"clear\":true} 恢复默认", group = "app"),
        ToolSpec("forget", "删除记忆", "{\"keyword\":\"关键词\"}", "删除包含关键词的记忆", group = "app"),
    )

    fun spec(name: String): ToolSpec? = ALL.firstOrNull { it.name == name }

    private val GROUP_HINTS = mapOf(
        "doc" to listOf("文件", "文档", "word", "docx", "ppt", "pptx", "幻灯", "演示", "excel", "xlsx", "表格", "pdf", "段落", "页", "合并", "转换", "转成", "另存", "下载", "目录", "备份", "还原", "改写", "润色"),
        "phone" to listOf("手机", "打开", "点击", "点一下", "屏幕", "通知", "剪贴板", "复制", "粘贴", "电量", "电池", "wifi", "存储", "应用", "app", "打电话", "拨打", "发消息", "发给", "微信", "qq", "短信",
            "联系人", "通讯录", "浏览器", "网址", "滑动", "返回", "桌面", "设置里", "帮我在", "操作", "抖音", "淘宝", "支付宝", "看看这个", "这页"),
        "home" to listOf("灯", "空调", "家居", "窗帘", "插座", "智能", "开关", "温度", "扫地"),
        "app" to listOf("主题", "背景", "皮肤", "换肤", "壁纸", "镜头", "手写", "页面", "忘记", "深色", "浅色", "夜间", "无极", "界面"),
    )

    /**
     * 根据设置、模式和用户的话决定本轮开放哪些工具。
     * 无极模式 / 云端模型上下文足够，直接开放全部；本地小模型按需开放相关工具组，节省上下文。
     */
    fun enabledNames(selfLoop: Boolean, userText: String = "", recentTools: Collection<String> = emptyList(), hasFiles: Boolean = false): Set<String> {
        if (selfLoop) {
            return if (DiaSettings.webEnabled.value || DiaSettings.wujiMode.value) setOf("web_search", "read_webpage", "calc") else setOf("calc")
        }
        val wuji = DiaSettings.wujiMode.value
        // 本地小模型上下文有限：即使在无极模式下也只放与这句话相关的工具组，免得提示词挤掉对话
        val ctx = DiaSettings.contextTokens.value
        val all = com.dia.app.llm.LlmGateway.usingCloud() || ctx >= 16384 || (wuji && ctx >= 12000)
        val text = userText.lowercase()
        val groups = HashSet<String>().apply { add("core") }
        if (all) groups.addAll(GROUP_HINTS.keys)
        else {
            for ((g, words) in GROUP_HINTS) if (words.any { text.contains(it) }) groups.add(g)
            if (hasFiles || Regex("\\bf\\d+\\b").containsMatchIn(text)) groups.add("doc")
            for (t in recentTools) spec(t)?.group?.let { groups.add(it) }
        }
        val out = LinkedHashSet<String>()
        for (t in ALL) if (t.group in groups) out.add(t.name)
        if (!wuji) {
            if (!DiaSettings.webEnabled.value) out.removeAll(setOf("web_search", "read_webpage", "download"))
            if (!DiaSettings.memoryEnabled.value) out.removeAll(setOf("remember", "recall", "forget"))
        }
        if (!FileManager.hasAllFilesAccess()) out.remove("list_files")
        return out
    }

    /** 卡片标题，例如「联网搜索：今天北京天气」。 */
    fun cardTitle(name: String, args: JSONObject): String {
        val t = spec(name)?.title ?: name
        fun fileName(k: String) = FileManager.find(args.optString(k))?.name ?: args.optString(k)
        val key = when (name) {
            "web_search" -> args.optString("query")
            "read_webpage", "download", "open_url" -> args.optString("url").ifBlank { args.optString("query") }
            "read_file", "edit_file", "restore_file", "rewrite_file", "doc_outline", "convert_file" -> fileName("file")
            "pdf_tool" -> args.optString("action") + " " + fileName("file")
            "create_file" -> args.optString("name")
            "translate" -> args.optString("text").ifBlank { FileManager.find(args.optString("file"))?.name.orEmpty() }
            "generate_image", "set_background" -> args.optString("prompt")
            "open_app" -> args.optString("name")
            "phone_task" -> args.optString("task")
            "phone_action" -> (args.optString("action") + " " + args.optString("text").ifBlank { args.optString("node_id") }).trim()
            "guide" -> args.optString("question")
            "remember" -> args.optString("content")
            "forget" -> args.optString("keyword")
            "recall", "contacts" -> args.optString("query")
            "list_files" -> args.optString("dir")
            "step_think" -> args.optString("question")
            "calc" -> args.optString("expr")
            "call_phone", "send_message" -> args.optString("contact")
            "smart_home" -> (args.optString("service") + " " + args.optString("entity_id")).trim()
            "open_page" -> args.optString("page")
            "set_theme" -> args.optString("mode")
            else -> ""
        }.take(40)
        return if (key.isBlank()) t else "$t：$key"
    }

    private fun str(a: JSONObject, vararg keys: String): String {
        for (k in keys) {
            val v = a.opt(k)
            if (v != null && v != JSONObject.NULL && v.toString().isNotBlank()) return v.toString().trim()
        }
        return ""
    }

    suspend fun execute(name: String, args: JSONObject, host: ToolHost): ToolOutcome = try {
        when (name) {
            "web_search" -> webSearch(str(args, "query", "q", "keyword", "text"), host)
            "read_webpage" -> readWeb(str(args, "url", "link"))
            "download" -> download(str(args, "url", "link"), str(args, "filename", "name"), host)
            "read_file" -> readFile(str(args, "file", "id", "path", "name"), args.optInt("offset", 0), host)
            "list_files" -> withContext(Dispatchers.IO) { ToolOutcome(FileManager.listDir(str(args, "dir", "path").ifBlank { null })) }
            "edit_file" -> DocTools.edit(args, host)
            "create_file" -> createFile(args, host)
            "rewrite_file" -> DocTools.rewrite(args, host)
            "doc_outline" -> DocTools.outline(args, host)
            "pdf_tool" -> DocTools.pdfTool(args, host)
            "convert_file" -> DocTools.convert(args, host)
            "restore_file" -> restoreFile(str(args, "file", "id", "name"), host)
            "translate" -> translate(args, host)
            "translate_screen" -> translateScreen(host)
            "generate_image" -> generateImage(str(args, "prompt", "description", "text"), str(args, "size"), host)
            "open_app" -> openApp(str(args, "name", "app", "app_name"), host)
            "phone_task" -> phoneTask(str(args, "task", "goal", "text"), host)
            "phone_action" -> DeviceTools.phoneAction(args, host)
            "read_screen" -> DeviceTools.readScreen(args, host)
            "look_screen" -> DeviceTools.lookScreen(args, host)
            "notifications" -> DeviceTools.notifications()
            "clipboard" -> DeviceTools.clipboard(args)
            "device_info" -> DeviceTools.deviceInfo(args)
            "list_apps" -> DeviceTools.listApps(args)
            "contacts" -> DeviceTools.contacts(args, host)
            "call_phone" -> DeviceTools.callPhone(args, host)
            "send_message" -> DeviceTools.sendMessage(args, host)
            "open_url" -> DeviceTools.openUrl(args, host)
            "guide" -> guide(str(args, "question", "task", "goal"), host)
            "smart_home" -> DeviceTools.smartHome(args)
            "open_page" -> DeviceTools.openPage(args)
            "set_theme" -> DeviceTools.setTheme(args)
            "set_background" -> DeviceTools.setBackground(args, host)
            "remember" -> remember(str(args, "content", "text", "memory"), str(args, "category").ifBlank { "其他" })
            "recall" -> recall(str(args, "query", "keyword", "text"))
            "forget" -> forget(str(args, "keyword", "content", "text"))
            "calc" -> calc(str(args, "expr", "expression", "formula", "text"))
            "step_think" -> StepThinker.asTool(str(args, "question", "query", "task", "text"), host)
            else -> ToolOutcome("没有名为 $name 的工具。可用工具：${ALL.joinToString(",") { it.name }}", ok = false)
        }
    } catch (e: kotlinx.coroutines.CancellationException) {
        throw e
    } catch (e: Exception) {
        Log.w(TAG, "$name failed", e)
        ToolOutcome("工具执行失败：${e.message ?: e.javaClass.simpleName}。可以换个参数或换个方法再试。", ok = false)
    }

    private fun calc(expr: String): ToolOutcome {
        if (expr.isBlank()) return ToolOutcome("缺少表达式 expr", ok = false)
        return try {
            ToolOutcome("$expr = ${Calc.format(Calc.eval(expr))}")
        } catch (e: Exception) {
            ToolOutcome("计算失败：${e.message}", ok = false)
        }
    }

    private fun recall(query: String): ToolOutcome {
        val items = if (query.isBlank()) MemoryStore.items.value.take(20) else MemoryStore.relevant(query, limit = 12, maxChars = 2000)
        if (items.isEmpty()) return ToolOutcome("记忆里没有找到相关内容。")
        return ToolOutcome(items.joinToString("\n") { "- [${it.category}] ${it.content}" })
    }

    // ───────── 联网 ─────────

    private suspend fun webSearch(query: String, host: ToolHost): ToolOutcome = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext ToolOutcome("缺少搜索词 query", ok = false)
        host.progress("正在搜索…")
        val r = WebSearch.search(query, 6)
        if (r.hits.isEmpty()) return@withContext ToolOutcome("搜索失败：${r.error}", ok = false)
        val sb = StringBuilder()
        for ((i, h) in r.hits.withIndex()) {
            sb.append("[${i + 1}] ${h.title}\n${h.url}\n${h.snippet}\n\n")
        }
        var forModel = sb.toString().trim()
        if (DiaSettings.deepSearch.value || host.wuji) {
            host.progress("正在阅读搜索结果网页…")
            val pages = StringBuilder()
            for (h in r.hits.take(if (host.wuji) 3 else 2)) {
                try {
                    val p = WebReader.read(h.url, if (host.wuji) 2500 else 1500)
                    if (p.text.isNotBlank()) pages.append("【${h.title}】\n${p.text}\n\n")
                } catch (_: Exception) { }
            }
            if (pages.isNotEmpty()) forModel += "\n\n=== 网页正文摘录 ===\n" + pages.toString().trim()
        }
        ToolOutcome(
            forModel = "（来自 ${r.engine} 的搜索结果，回答时可用 [序号] 标注来源）\n$forModel",
            display = sb.toString().trim(),
        )
    }

    private suspend fun readWeb(url: String): ToolOutcome = withContext(Dispatchers.IO) {
        if (url.isBlank()) return@withContext ToolOutcome("缺少网址 url", ok = false)
        val p = WebReader.read(url, 4000)
        val head = if (p.title.isNotBlank()) "标题：${p.title}\n" else ""
        ToolOutcome("${head}网址：${p.url}\n\n${p.text.ifBlank { "（网页没有可读的正文）" }}", display = "$head${p.text.take(1500)}")
    }

    private suspend fun download(url: String, filename: String, host: ToolHost): ToolOutcome {
        if (!url.startsWith("http")) return ToolOutcome("下载地址无效：$url", ok = false)
        val probe = withContext(Dispatchers.IO) { WebDownloader.probe(url, filename.ifBlank { null }) }
        val ok = host.confirm(
            "下载文件到手机？",
            "文件：${probe.fileName}\n大小：${WebDownloader.formatSize(probe.sizeBytes)}\n类型：${probe.mime ?: "未知"}\n来源：$url\n保存到：下载/Dia/",
        )
        if (!ok) return ToolOutcome("用户拒绝了下载。", ok = false)
        val id = WebDownloader.enqueue(host.context, probe)
        var status = "已开始下载"
        for (i in 0 until 10) {
            delay(1000)
            val (s, done) = WebDownloader.status(host.context, id)
            status = s
            host.progress(s)
            if (done) break
        }
        return ToolOutcome("已提交下载：${probe.fileName}，当前状态：$status。下载完成后在通知栏和「下载/Dia」里可以找到。")
    }

    // ───────── 文件 ─────────

    private suspend fun readFile(key: String, offset: Int, host: ToolHost): ToolOutcome {
        val ref = FileManager.find(key)
            ?: return ToolOutcome("找不到文件「$key」。请让用户点 ＋ →「文件」先选择文件。", ok = false)
        host.progress("正在读取 ${ref.name}…")
        val budget = (LlmGateway.promptCharBudget() / 2).coerceIn(1200, 12000)
        val r = withContext(Dispatchers.IO) { FileManager.read(ref, offset, budget) }
        if (r.text.isBlank() && r.images.isNotEmpty()) {
            host.progress("扫描版 PDF，正在识别文字…")
            val ocr = StringBuilder()
            for ((i, img) in r.images.withIndex()) {
                val t = LlmGateway.complete(
                    system = "你是 OCR 文字识别引擎。逐字输出图片中的全部文字，保持原有段落，不要解释。",
                    prompt = "识别这一页的文字：",
                    images = listOf(img),
                    temperature = 0.1,
                )
                ocr.append("【第${i + 1}页】\n").append(t.trim()).append("\n\n")
            }
            return ToolOutcome("${ref.name}（${r.note}）\n\n$ocr", display = ocr.toString().take(2000))
        }
        val end = offset + r.text.length
        val more = if (end < r.totalChars) "\n\n（全文共 ${r.totalChars} 字，当前显示 ${offset}–$end。需要继续请用 offset=$end）" else ""
        val note = if (r.note.isNotBlank()) "\n（${r.note}）" else ""
        val pages = if (r.pages > 0) "，共 ${r.pages} 页" else ""
        return ToolOutcome(
            "文件 ${ref.id}《${ref.name}》（${ref.kind}$pages）内容：\n${r.text}$more$note",
            display = r.text.take(1500) + if (r.text.length > 1500) "…" else "",
        )
    }

    private suspend fun createFile(args: JSONObject, host: ToolHost): ToolOutcome {
        val name = str(args, "name", "filename", "title").ifBlank { "灵犀文档" }
        val content = args.optString("content", args.optString("text", ""))
        val format = FileManager.normalizeFormat(str(args, "format", "type", "ext"), name)
        if (content.isBlank()) return ToolOutcome("缺少文件内容 content", ok = false)
        val label = mapOf("docx" to "Word", "pptx" to "PPT", "xlsx" to "Excel", "pdf" to "PDF").getOrDefault(format, format)
        val ok = host.confirm(
            "新建文件「$name」？",
            "格式：$label\n长度：${content.length} 字\n保存到：下载/Dia/\n\n预览：${content.take(200)}${if (content.length > 200) "…" else ""}",
        )
        if (!ok) return ToolOutcome("用户取消了新建文件。", ok = false)
        host.progress("正在生成 $label…")
        val ref = withContext(Dispatchers.IO) { FileManager.createFile(name, content, format) }
        return ToolOutcome("已新建文件 ${ref.id}《${ref.name}》，保存在「下载/Dia」目录。之后可以用 ${ref.id} 继续修改。")
    }

    private suspend fun restoreFile(key: String, host: ToolHost): ToolOutcome {
        val list = FileManager.backupsFor(key)
        val latest = list.firstOrNull() ?: return ToolOutcome("没有找到「$key」的备份。", ok = false)
        val ok = host.confirm(
            "还原文件「${latest.name}」？",
            "还原到：${FileManager.formatTime(latest.time)}（${latest.note}）\n当前版本会先自动备份。",
        )
        if (!ok) return ToolOutcome("用户取消了还原。", ok = false)
        val res = withContext(Dispatchers.IO) { FileManager.restore(latest.id) }
        return ToolOutcome(res)
    }

    // ───────── 翻译 ─────────

    private suspend fun translate(args: JSONObject, host: ToolHost): ToolOutcome {
        val to = str(args, "to", "target", "lang", "language").ifBlank { DiaSettings.translateTarget.value }
        var text = args.optString("text", "")
        val fileKey = str(args, "file")
        // 整份 Word / PPT / PDF：保留排版，另存一份译文
        val fileRef = if (text.isBlank() && fileKey.isNotBlank()) FileManager.find(fileKey) else null
        if (fileRef != null && fileRef.ext in setOf("docx", "pptx", "pdf") && args.optBoolean("keep_format", true)) {
            val a = JSONObject().put("file", fileRef.id).put("save_as", true).put("suffix", to)
                .put("instruction", "翻译成$to：准确、通顺、符合$to 的表达习惯，专有名词保留或采用通行译法")
            return DocTools.rewrite(a, host)
        }
        if (text.isBlank() && fileKey.isNotBlank()) {
            val ref = FileManager.find(fileKey) ?: return ToolOutcome("找不到文件「$fileKey」", ok = false)
            host.progress("正在读取 ${ref.name}…")
            text = withContext(Dispatchers.IO) { FileManager.read(ref, 0, 8000).text }
        }
        if (text.isBlank()) return ToolOutcome("缺少要翻译的内容", ok = false)
        val chunks = chunk(text, 1200)
        val out = StringBuilder()
        for ((i, c) in chunks.withIndex()) {
            if (chunks.size > 1) host.progress("翻译中 ${i + 1}/${chunks.size}…")
            val t = LlmGateway.complete(
                system = "你是专业翻译。把用户给出的内容翻译成$to。要求：准确、通顺、符合$to 的表达习惯；保留原有格式、换行和专有名词；只输出译文，不要解释，不要加引号。",
                prompt = c,
                temperature = 0.2,
            )
            out.append(t.trim()).append('\n')
        }
        val result = out.toString().trim()
        return if (result.length > 600) {
            ToolOutcome(
                forModel = "译文（共 ${result.length} 字）已完整展示给用户。开头：${result.take(300)}…\n请只用一两句话告诉用户翻译已完成，不要重复译文。",
                display = result,
                shownToUser = true,
            )
        } else {
            ToolOutcome("译文：\n$result", display = result)
        }
    }

    fun chunk(text: String, size: Int): List<String> {
        if (text.length <= size) return listOf(text)
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (line in text.split('\n')) {
            if (sb.length + line.length + 1 > size && sb.isNotEmpty()) {
                out.add(sb.toString()); sb.setLength(0)
            }
            if (line.length > size) {
                var i = 0
                while (i < line.length) { out.add(line.substring(i, minOf(line.length, i + size))); i += size }
            } else {
                sb.append(line).append('\n')
            }
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return out
    }

    private fun translateScreen(host: ToolHost): ToolOutcome {
        if (!DiaAccessibilityService.isRunning()) {
            return ToolOutcome("需要先开启无障碍服务：设置 → 权限 → 无障碍，打开「灵犀 Dia」。", ok = false)
        }
        if (!com.dia.app.screen.QuickActionService.hasOverlayPermission(host.context)) {
            return ToolOutcome("需要“显示在其他应用上层”权限：设置 → 权限 → 悬浮窗。", ok = false)
        }
        host.moveAppToBack()
        com.dia.app.translate.ScreenTranslateService.start(
            host.context, com.dia.app.translate.ScreenTranslateService.Mode.TRANSLATE,
        )
        return ToolOutcome("已切到上一个应用，请在屏幕上框选要翻译的区域，结果会浮在屏幕上，也可以点「发到对话」带回来。", shownToUser = true)
    }

    // ───────── 生图 ─────────

    suspend fun generateImage(prompt: String, size: String, host: ToolHost): ToolOutcome {
        if (prompt.isBlank()) return ToolOutcome("缺少画面描述 prompt", ok = false)
        var finalPrompt = prompt
        val provider = DiaSettings.imageProvider.value
        if (DiaSettings.imagePromptTranslate.value && provider != "openai" && LlmGateway.isAvailable() &&
            prompt.any { it.code in 0x4E00..0x9FFF }
        ) {
            host.progress("正在润色提示词…")
            try {
                finalPrompt = LlmGateway.complete(
                    system = "把用户的中文画面描述改写成适合 Stable Diffusion / FLUX 的英文提示词：保留所有要素，补充画风、光线、构图等细节，用逗号分隔的短语，不超过 60 个词。只输出英文提示词。",
                    prompt = prompt,
                    temperature = 0.3,
                    timeoutMs = 60_000,
                ).trim().lines().firstOrNull { it.isNotBlank() }?.trim()?.trim('"')?.ifBlank { prompt } ?: prompt
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
                finalPrompt = prompt
            }
        }
        host.progress("${ImageGen.providerLabel(provider)} 正在作画…")
        val r = withContext(Dispatchers.IO) { ImageGen.generate(finalPrompt, size.ifBlank { null }) }
        return ToolOutcome(
            forModel = "图片已生成并展示给用户（提示词：$finalPrompt）。请用一句话简短说明画了什么。",
            display = "提示词：$finalPrompt",
            imagePath = r.path,
            shownToUser = true,
        )
    }

    // ───────── 手机操控 ─────────

    private val APP_ALIASES = mapOf(
        "微信" to "com.tencent.mm", "wechat" to "com.tencent.mm", "qq" to "com.tencent.mobileqq",
        "支付宝" to "com.eg.android.AlipayGphone", "淘宝" to "com.taobao.taobao", "抖音" to "com.ss.android.ugc.aweme",
        "京东" to "com.jingdong.app.mall", "美团" to "com.sankuai.meituan", "哔哩哔哩" to "tv.danmaku.bili",
        "b站" to "tv.danmaku.bili", "小红书" to "com.xingin.xhs", "高德地图" to "com.autonavi.minimap",
        "百度地图" to "com.baidu.BaiduMap", "微博" to "com.sina.weibo", "拼多多" to "com.xunmeng.pinduoduo",
        "网易云音乐" to "com.netease.cloudmusic", "钉钉" to "com.alibaba.android.rimet", "飞书" to "com.ss.android.lark",
    )

    private fun openApp(name: String, host: ToolHost): ToolOutcome {
        if (name.isBlank()) return ToolOutcome("缺少应用名", ok = false)
        val ctx = host.context
        val pm = ctx.packageManager
        val key = name.trim().lowercase()
        var pkg: String? = APP_ALIASES[key]?.takeIf { pm.getLaunchIntentForPackage(it) != null }
        if (pkg == null) {
            val main = android.content.Intent(android.content.Intent.ACTION_MAIN)
                .addCategory(android.content.Intent.CATEGORY_LAUNCHER)
            val apps = try { pm.queryIntentActivities(main, 0) } catch (_: Exception) { emptyList() }
            val labeled = apps.map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            pkg = labeled.firstOrNull { it.second.equals(name.trim(), true) }?.first
                ?: labeled.firstOrNull { it.second.contains(name.trim(), true) || name.contains(it.second, true) && it.second.length >= 2 }?.first
                ?: labeled.firstOrNull { it.first.contains(key) }?.first
        }
        val intent = pkg?.let { pm.getLaunchIntentForPackage(it) }
            ?: return ToolOutcome("没有找到名为「$name」的应用。", ok = false)
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        return ToolOutcome("已打开「$name」。")
    }

    private suspend fun phoneTask(task: String, host: ToolHost): ToolOutcome {
        if (task.isBlank()) return ToolOutcome("缺少任务描述", ok = false)
        if (!DiaAccessibilityService.isRunning()) {
            return ToolOutcome("操控手机需要先开启无障碍服务：设置 → 权限 → 无障碍，打开「灵犀 Dia」。", ok = false)
        }
        if (PilotAgent.isRunning()) return ToolOutcome("已有一个手机任务正在执行，请稍后。", ok = false)
        val ok = host.confirm("允许灵犀操控手机？", "任务：$task\n\n灵犀会自动打开应用、点击和输入。执行中可在通知栏停止。")
        if (!ok) return ToolOutcome("用户拒绝了操控手机。", ok = false)
        PilotAgent.attach(host.context)
        return coroutineScope {
            val done = CompletableDeferred<String>()
            val steps = StringBuilder()
            val collector = launch(start = CoroutineStart.UNDISPATCHED) {
                PilotAgent.events.collect { e ->
                    when (e) {
                        is PilotEvent.Step -> { steps.append("· ").append(e.message).append('\n'); host.progress(e.message) }
                        is PilotEvent.ToolCall -> host.progress("执行：${e.name}")
                        is PilotEvent.Finished -> done.complete("完成：${e.summary}")
                        is PilotEvent.Failed -> done.complete("失败：${e.error}")
                        else -> Unit
                    }
                }
            }
            PilotAgent.start(task)
            val result = withTimeoutOrNull(if (host.wuji) 60 * 60_000L else 10 * 60_000L) { done.await() } ?: run {
                PilotAgent.stop()
                "超时，已停止"
            }
            collector.cancel()
            ToolOutcome("手机任务「$task」$result", display = "$result\n\n过程：\n$steps".trim(), ok = !result.startsWith("失败"))
        }
    }

    private fun guide(question: String, host: ToolHost): ToolOutcome {
        if (question.isBlank()) return ToolOutcome("缺少引导问题", ok = false)
        if (!DiaAccessibilityService.isRunning()) return ToolOutcome("屏幕引导需要开启无障碍服务。", ok = false)
        if (!com.dia.app.guide.GuideOverlayService.hasOverlayPermission(host.context)) {
            return ToolOutcome("屏幕引导需要“显示在其他应用上层”权限。", ok = false)
        }
        com.dia.app.guide.GuideOverlayService.start(host.context, question)
        return ToolOutcome("已开始屏幕引导：$question。灵犀会在屏幕上一步步指示。", shownToUser = true)
    }

    // ───────── 记忆 ─────────

    private fun remember(content: String, category: String): ToolOutcome {
        if (content.isBlank()) return ToolOutcome("缺少要记住的内容", ok = false)
        val m = MemoryStore.add(content, category, source = "manual") ?: return ToolOutcome("内容太短，没有记录", ok = false)
        return ToolOutcome("已记住：${m.content}")
    }

    private fun forget(keyword: String): ToolOutcome {
        if (keyword.isBlank()) return ToolOutcome("缺少关键词", ok = false)
        val n = MemoryStore.forget(keyword)
        return ToolOutcome(if (n > 0) "已删除 $n 条包含「$keyword」的记忆" else "没有包含「$keyword」的记忆")
    }
}
