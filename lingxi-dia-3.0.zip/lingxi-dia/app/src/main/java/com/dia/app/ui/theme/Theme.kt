package com.dia.app.ui.theme

import android.app.Activity
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.dia.app.prefs.DiaSettings

private fun schemeFor(p: DiaPalette): ColorScheme =
    if (p.isDark) {
        darkColorScheme(
            primary = p.cinnabar,
            onPrimary = p.onCinnabar,
            primaryContainer = p.userBubble,
            onPrimaryContainer = p.onUserBubble,
            secondary = p.gold,
            onSecondary = p.background,
            secondaryContainer = p.gold.copy(alpha = 0.2f),
            onSecondaryContainer = p.text,
            tertiary = p.indigo,
            onTertiary = p.background,
            tertiaryContainer = p.indigo.copy(alpha = 0.2f),
            onTertiaryContainer = p.text,
            background = p.background,
            onBackground = p.text,
            surface = p.surface,
            onSurface = p.text,
            surfaceVariant = p.surfaceAlt,
            onSurfaceVariant = p.textSecondary,
            surfaceContainerHighest = p.surfaceAlt,
            surfaceContainerHigh = p.surfaceAlt,
            surfaceContainer = p.surface,
            surfaceContainerLow = p.surface,
            outline = p.border,
            outlineVariant = p.border,
            error = p.error,
            onError = p.onCinnabar,
        )
    } else {
        lightColorScheme(
            primary = p.cinnabar,
            onPrimary = p.onCinnabar,
            primaryContainer = p.cinnabar.copy(alpha = 0.15f),
            onPrimaryContainer = p.text,
            secondary = p.gold,
            onSecondary = p.surface,
            secondaryContainer = p.gold.copy(alpha = 0.18f),
            onSecondaryContainer = p.text,
            tertiary = p.indigo,
            onTertiary = p.surface,
            tertiaryContainer = p.indigo.copy(alpha = 0.18f),
            onTertiaryContainer = p.text,
            background = p.background,
            onBackground = p.text,
            surface = p.surface,
            onSurface = p.text,
            surfaceVariant = p.surfaceAlt,
            onSurfaceVariant = p.textSecondary,
            surfaceContainerHighest = p.surfaceAlt,
            surfaceContainerHigh = p.surfaceAlt,
            surfaceContainer = p.surface,
            surfaceContainerLow = p.surface,
            outline = p.border,
            outlineVariant = p.border,
            error = p.error,
            onError = p.onCinnabar,
        )
    }

@Composable
private fun ApplyPalette(palette: DiaPalette, content: @Composable () -> Unit) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val activity = view.context as? Activity
            if (activity != null) {
                val window = activity.window
                WindowCompat.setDecorFitsSystemWindows(window, false)
                WindowCompat.getInsetsController(window, view).apply {
                    isAppearanceLightStatusBars = !palette.isDark
                    isAppearanceLightNavigationBars = !palette.isDark
                }
            }
        }
    }
    CompositionLocalProvider(LocalDiaPalette provides palette) {
        MaterialTheme(
            colorScheme = schemeFor(palette),
            typography = DiaTypography,
            content = content,
        )
    }
}

/** 应用主题：宣纸山水 / 江湖夜色；开启无极模式时自动换成无极墨金。 */
@Composable
fun DiaTheme(content: @Composable () -> Unit) {
    val mode by DiaSettings.themeMode.flow.collectAsState()
    val wuji by DiaSettings.wujiMode.flow.collectAsState()
    ApplyPalette(paletteFor(if (wuji) "wuji" else mode), content)
}

/**
 * 老功能页（实时镜头、手写板、引导…）的颜色是固定的深色常量，
 * 用它包一层，保证这些页面始终是「江湖夜色」风格、状态栏图标正确。
 */
@Composable
fun InkTheme(content: @Composable () -> Unit) {
    ApplyPalette(InkPalette, content)
}
