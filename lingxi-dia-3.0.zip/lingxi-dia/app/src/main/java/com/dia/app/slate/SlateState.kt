package com.dia.app.slate

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import java.util.concurrent.atomic.AtomicLong

/** Page background style. Plain by default for a notebook feel. */
enum class PageBackground { PLAIN, RULED, GRID, DOTS }

/** Status of the last AI reply for a page. */
enum class AiStatus { IDLE, ASKING, ERROR }

/**
 * One AI-generated note pinned to a page. Replies are typed text shown
 * in a card overlay — NOT synthesised handwriting. Position is
 * page-space; size is decided by the renderer.
 */
data class AiNote(
    val id: Long,
    val text: String,
    /** Where on the page the note's top-left should sit. Page-space px. */
    val anchor: Offset,
    val verdict: QuizVerdict? = null,  // only used by Quiz pages
    val correctAnswer: String? = null, // only used by Quiz pages
)

enum class QuizVerdict { CORRECT, INCORRECT, UNGRADED }

/**
 * One page in the notebook. Fixed size (set when the page is created).
 * Pages are A5-aspect by default but you can vary by mode.
 */
class NotebookPage(
    val id: Long,
    /** Page width in page-space px. */
    val width: Float,
    /** Page height in page-space px. */
    val height: Float,
    /** Optional question shown above the canvas (Quiz mode). */
    val question: String? = null,
) {
    val strokes: SnapshotStateList<Stroke> = mutableStateListOf()
    val aiNotes: SnapshotStateList<AiNote> = mutableStateListOf()
    var aiStatus by mutableStateOf(AiStatus.IDLE)
    var aiStatusText by mutableStateOf("")

    private val undoStack = ArrayDeque<UndoFrame>()

    fun addStroke(s: Stroke) {
        strokes.add(s)
        undoStack.addLast(UndoFrame.AddStroke(s.id))
    }

    fun addAiStroke(s: Stroke) {
        strokes.add(s)
        undoStack.addLast(UndoFrame.AddStroke(s.id))
    }

    fun eraseAlong(eraser: Stroke) {
        val r2 = eraser.width * eraser.width
        val removed = ArrayList<Stroke>()
        val it = strokes.listIterator()
        while (it.hasNext()) {
            val s = it.next()
            // bbox reject
            if (eraser.maxX < s.minX - eraser.width || eraser.minX > s.maxX + eraser.width ||
                eraser.maxY < s.minY - eraser.width || eraser.minY > s.maxY + eraser.width
            ) continue
            outer@ for (ep in eraser.points) {
                for (sp in s.points) {
                    val dx = sp.x - ep.x
                    val dy = sp.y - ep.y
                    if (dx * dx + dy * dy <= r2) {
                        it.remove()
                        removed.add(s)
                        break@outer
                    }
                }
            }
        }
        if (removed.isNotEmpty()) undoStack.addLast(UndoFrame.RemoveStrokes(removed))
    }

    /**
     * Live point eraser: removes any stroke whose points fall within
     * [radius] of [center]. Called per pointer-move while the eraser
     * tool is active so the user sees strokes vanish as they drag.
     *
     * Returns true if anything was removed.
     */
    fun eraseAtPoint(center: androidx.compose.ui.geometry.Offset, radius: Float): Boolean {
        if (strokes.isEmpty()) return false
        val r = radius
        val r2 = r * r
        val removed = ArrayList<Stroke>()
        val it = strokes.listIterator()
        while (it.hasNext()) {
            val s = it.next()
            // bbox reject
            if (center.x + r < s.minX || center.x - r > s.maxX ||
                center.y + r < s.minY || center.y - r > s.maxY
            ) continue
            // hit-test
            for (sp in s.points) {
                val dx = sp.x - center.x
                val dy = sp.y - center.y
                if (dx * dx + dy * dy <= r2) {
                    it.remove()
                    removed.add(s)
                    break
                }
            }
        }
        if (removed.isNotEmpty()) {
            undoStack.addLast(UndoFrame.RemoveStrokes(removed))
            return true
        }
        return false
    }

    fun addAiNote(n: AiNote) { aiNotes.add(n); undoStack.addLast(UndoFrame.AddAiNote(n.id)) }
    fun setLastAiNoteVerdict(v: QuizVerdict, correctAnswer: String?) {
        val last = aiNotes.lastOrNull() ?: return
        val replaced = last.copy(verdict = v, correctAnswer = correctAnswer ?: last.correctAnswer)
        aiNotes[aiNotes.lastIndex] = replaced
    }

    fun undo() {
        val f = undoStack.removeLastOrNull() ?: return
        when (f) {
            is UndoFrame.AddStroke -> {
                val idx = strokes.indexOfFirst { it.id == f.id }
                if (idx >= 0) strokes.removeAt(idx)
            }
            is UndoFrame.RemoveStrokes -> strokes.addAll(f.strokes)
            is UndoFrame.AddAiNote -> {
                val idx = aiNotes.indexOfFirst { it.id == f.id }
                if (idx >= 0) aiNotes.removeAt(idx)
            }
        }
    }

    fun clearAll() {
        if (strokes.isEmpty() && aiNotes.isEmpty()) return
        val s = strokes.toList()
        strokes.clear()
        aiNotes.clear()
        if (s.isNotEmpty()) undoStack.addLast(UndoFrame.RemoveStrokes(s))
    }

    fun isEmpty(): Boolean = strokes.isEmpty() && aiNotes.isEmpty()

    private sealed interface UndoFrame {
        data class AddStroke(val id: Long) : UndoFrame
        data class RemoveStrokes(val strokes: List<Stroke>) : UndoFrame
        data class AddAiNote(val id: Long) : UndoFrame
    }
}

/** Notebook mode — Notes is a freeform notebook, Quiz is the 10-question quiz subfeature. */
enum class NotebookMode { NOTES, QUIZ }

/**
 * The state holder for one open Slate notebook. Has a list of pages and
 * a current-page index. Survives recomposition; serialized via
 * [SlateStore] for persistence.
 */
class SlateState(
    val id: String,
    title: String,
    val mode: NotebookMode = NotebookMode.NOTES,
) {
    private val nextStrokeId = AtomicLong(1L)
    private val nextNoteId = AtomicLong(1_000_000L)
    private val nextPageId = AtomicLong(1L)

    var title by mutableStateOf(title)
    val pages = mutableStateListOf<NotebookPage>()
    var currentPageIndex by mutableStateOf(0)

    // ── Tools ──
    var penMode by mutableStateOf(PenMode.PEN)
    var penColor by mutableStateOf(InkOnPaper)
    var penWidth by mutableStateOf(3.5f)
    var pageBackground by mutableStateOf(PageBackground.RULED)

    // ── Active stroke being drawn (page-space) ──
    var currentStroke by mutableStateOf<Stroke?>(null)
    /**
     * Stroke currently being animated by the AI replay — drawn on top
     * of the page just like [currentStroke] so the user sees it appear
     * point-by-point. Cleared when the stroke finishes and is committed
     * to the page via [NotebookPage.addAiStroke].
     */
    var currentAiStroke by mutableStateOf<Stroke?>(null)
    /**
     * Page-space position of the eraser cursor while the user is
     * actively erasing. Drawn as a faint circle so the user can see
     * where the eraser tip is.
     */
    var eraserPos by mutableStateOf<androidx.compose.ui.geometry.Offset?>(null)
    var liveStrokeTick by mutableStateOf(0)
        private set

    /** Bump the live tick from outside (used by AI replay + eraser). */
    fun bumpLiveTick() { liveStrokeTick++ }

    // ── Per-page zoom ──
    /** Zoom factor applied around the page's centre. 1.0 = fit-to-screen. */
    var zoom by mutableStateOf(1f)
    /**
     * Pan offset in page-space px applied AFTER zoom. 0,0 = page is
     * centered (in fit-to-screen mode). Bounded so the page can't be
     * dragged off-screen.
     */
    var pan by mutableStateOf(Offset.Zero)

    val currentPage: NotebookPage?
        get() = pages.getOrNull(currentPageIndex)

    fun newStrokeId(): Long = nextStrokeId.getAndIncrement()
    fun newNoteId(): Long = nextNoteId.getAndIncrement()
    fun newPageId(): Long = nextPageId.getAndIncrement()

    fun addPage(page: NotebookPage) { pages.add(page) }

    // ── Stroke editing ──
    fun beginStroke(p: InkPoint) {
        // ERASER doesn't go through here — see PageCanvas.drawingGesture.
        val color = if (penMode == PenMode.HIGHLIGHTER) Color(0x885E97FF) else penColor
        val width = if (penMode == PenMode.HIGHLIGHTER) penWidth * 6f else penWidth
        val s = Stroke(
            id = newStrokeId(),
            color = color,
            width = width,
            mode = penMode,
        )
        s.add(p)
        currentStroke = s
        liveStrokeTick++
    }

    fun extendStroke(p: InkPoint) {
        val s = currentStroke ?: return
        val last = s.points.lastOrNull()
        if (last != null) {
            val dx = p.x - last.x
            val dy = p.y - last.y
            if (dx * dx + dy * dy < 0.25f) return
        }
        s.add(p)
        liveStrokeTick++
    }

    fun endStroke() {
        val s = currentStroke ?: return
        val page = currentPage
        if (page != null && s.points.size >= 2) {
            // ERASER never goes through beginStroke any more, so anything
            // arriving here is a real ink stroke.
            page.addStroke(s)
        }
        currentStroke = null
    }

    fun cancelStroke() {
        currentStroke = null
        liveStrokeTick++
    }

    fun resetView() {
        zoom = 1f
        pan = Offset.Zero
    }

    companion object {
        val DefaultInk = Color(0xFFEAEAF2)
        val PaperColor = Color(0xFFFAF7F0)
        val PaperRule = Color(0xFFC9C0AE)
        val InkOnPaper = Color(0xFF1F2230)
        const val PAGE_WIDTH = 1240f      // page-space px (fixed for all pages)
        const val PAGE_HEIGHT = 1754f     // 1.414 ratio (A-series)
    }
}

@Suppress("unused")
fun SlateState.observeChanges() = snapshotFlow {
    pages.sumOf { p -> p.strokes.size + p.aiNotes.size } + currentPageIndex
}
