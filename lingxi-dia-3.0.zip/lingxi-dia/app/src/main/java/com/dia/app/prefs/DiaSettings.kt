package com.dia.app.prefs

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 新增功能的设置（记忆 / 联网 / 文件 / 生图 / 主题 / 自循环 …）。
 *
 * 与 [DiaPrefs] 共用同一个 SharedPreferences 文件，但每一项都是一个
 * 独立的可观察对象，Compose 中直接 `xxx.flow.collectAsState()` 即可。
 */
abstract class PrefItem<T>(protected val key: String, protected val def: T) {
    protected val state = MutableStateFlow(def)
    val flow: StateFlow<T> = state.asStateFlow()
    val value: T get() = state.value

    abstract fun load(sp: SharedPreferences)
    protected abstract fun write(editor: SharedPreferences.Editor, v: T)

    fun set(v: T) {
        state.value = v
        val sp = DiaSettings.prefsOrNull() ?: return
        val e = sp.edit()
        write(e, v)
        e.apply()
    }
}

class StringPref(key: String, def: String) : PrefItem<String>(key, def) {
    override fun load(sp: SharedPreferences) { state.value = sp.getString(key, def) ?: def }
    override fun write(editor: SharedPreferences.Editor, v: String) { editor.putString(key, v) }
}

class BoolPref(key: String, def: Boolean) : PrefItem<Boolean>(key, def) {
    override fun load(sp: SharedPreferences) { state.value = sp.getBoolean(key, def) }
    override fun write(editor: SharedPreferences.Editor, v: Boolean) { editor.putBoolean(key, v) }
}

class IntPref(key: String, def: Int) : PrefItem<Int>(key, def) {
    override fun load(sp: SharedPreferences) { state.value = sp.getInt(key, def) }
    override fun write(editor: SharedPreferences.Editor, v: Int) { editor.putInt(key, v) }
}

object DiaSettings {

    private const val PREFS_NAME = "dia_prefs"

    @Volatile
    private var sp: SharedPreferences? = null
    private val items = ArrayList<PrefItem<*>>()

    internal fun prefsOrNull(): SharedPreferences? = sp

    private fun s(key: String, def: String) = StringPref(key, def).also { items.add(it) }
    private fun b(key: String, def: Boolean) = BoolPref(key, def).also { items.add(it) }
    private fun i(key: String, def: Int) = IntPref(key, def).also { items.add(it) }

    // ── 外观 ──
    /** "ink" = 江湖夜（深色水墨），"paper" = 宣纸山水（浅色），"wuji" = 无极（墨金太极） */
    val themeMode = s("theme_mode", "paper")
    /** 自定义对话背景图（本地路径，空 = 使用内置水墨背景）。 */
    val customBgPath = s("custom_bg_path", "")
    /** 背景图浓淡（0~100，越大越清晰）。 */
    val bgStrength = i("bg_strength", 70)

    // ── 模型 / 对话 ──
    /** 本地模型上下文长度（token），重新加载模型后生效。 */
    val contextTokens = i("context_tokens", 8192)
    /** 允许 AI 自行决定调用工具（搜索 / 文件 / 生图 / 操控手机 …）。 */
    val agentTools = b("agent_tools", true)
    /** 回复默认语言。 */
    val replyLanguage = s("reply_language", "简体中文")
    /** 单轮最多调用工具次数；0 = 不限（以完成任务为准）。 */
    val maxToolSteps = i("max_tool_steps_v3", 0)
    /** 自动批准修改文件、下载、操控手机等操作（不再弹确认卡片）。 */
    val autoApprove = b("auto_approve", false)

    // ── 无极模式 ──
    /** 无极模式：调动全部权限 + 深度思考 + 分布式思考 + 自动续航，直到任务完成。 */
    val wujiMode = b("wuji_mode", false)
    /** 无极模式的「分身」数量（分布式思考时并行求解子问题 / 会审的角色数）。 */
    val wujiWorkers = i("wuji_workers", 3)
    /** 无极模式完成后自检任务是否真正完成，未完成则自动接着做。 */
    val wujiSelfCheck = b("wuji_self_check", true)

    // ── 分步思考 ──
    /** off = 关闭；auto = 遇到复杂问题自动启用；on = 每个问题都分步思考 */
    val stepThinking = s("step_thinking", "auto")
    /** 拆解前先联网检索，帮助把问题拆得更准。 */
    val stepPreSearch = b("step_pre_search", true)
    /** 最大拆解层数（1~4）。 */
    val stepMaxDepth = i("step_max_depth", 3)
    /** 每层最多子问题数（2~6）。 */
    val stepMaxBranch = i("step_max_branch", 4)

    // ── 记忆 ──
    val memoryEnabled = b("memory_enabled", true)
    /** 每轮对话后自动提取关键信息写入记忆。 */
    val autoMemory = b("auto_memory", true)

    // ── 联网 ──
    val webEnabled = b("web_enabled", true)
    /** bing / duckduckgo / searxng */
    val searchEngine = s("search_engine", "bing")
    val searxngUrl = s("searxng_url", "")
    /** 搜索后自动读取前几个网页正文，回答更准确（更慢）。 */
    val deepSearch = b("deep_search", false)

    // ── 翻译 ──
    val translateTarget = s("translate_target", "简体中文")

    // ── 语音 ──
    val voiceLanguage = s("voice_language", "zh-CN")
    /** 语音转文字后自动发送。 */
    val voiceAutoSend = b("voice_auto_send", true)
    /** 语音对话：回复（文字显示）读完后自动继续听下一句。 */
    val voiceConversation = b("voice_conversation", false)
    /** 语音对话时自动朗读回复。 */
    val voiceSpeakReply = b("voice_speak_reply", true)

    // ── 生图 ──
    /** pollinations / openai / sdwebui / local */
    val imageProvider = s("image_provider", "pollinations")
    val imageBaseUrl = s("image_base_url", "")
    val imageApiKey = s("image_api_key", "")
    val imageModel = s("image_model", "")
    val imageSize = s("image_size", "1024x1024")
    /** 生图前用对话模型把中文提示词翻译 / 润色成英文。 */
    val imagePromptTranslate = b("image_prompt_translate", true)
    /** 本机生图模型下载地址（zip，内含 MediaPipe 格式 bins）。 */
    val localImageModelUrl = s("local_image_model_url", "")
    val localImageSteps = i("local_image_steps", 20)

    // ── 自循环 ──
    val selfLoopRounds = i("self_loop_rounds", 6)
    val selfLoopRoleA = s("self_loop_role_a", "提问者")
    val selfLoopRoleB = s("self_loop_role_b", "解答者")

    fun init(context: Context) {
        if (sp != null) return
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        sp = prefs
        for (item in items) {
            try { item.load(prefs) } catch (_: Exception) { }
        }
    }
}
