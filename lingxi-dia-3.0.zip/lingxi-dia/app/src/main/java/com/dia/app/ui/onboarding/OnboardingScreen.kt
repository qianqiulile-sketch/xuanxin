package com.dia.app.ui.onboarding

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Accessibility
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.Contacts
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Sms
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.dia.app.ui.components.GlassCard
import com.dia.app.ui.components.iconGlow
import com.dia.app.ui.home.DiaLogo
import com.dia.app.ui.theme.DiaAccent
import com.dia.app.ui.theme.DiaAccentSecondary
import com.dia.app.ui.theme.DiaBackground
import com.dia.app.ui.theme.inkPageBackground
import com.dia.app.ui.theme.DiaSuccess
import com.dia.app.ui.theme.DiaTextSecondary
import com.dia.app.ui.theme.DiaTextTertiary
import com.dia.app.ui.theme.DiaWarning

data class PermissionItem(
    val id: String,
    val title: String,
    val description: String,
    val icon: ImageVector,
    val androidPermission: String? = null,
    val isSpecial: Boolean = false,
    val settingsAction: String? = null,
    val accentColor: Color = DiaAccent
)

@Composable
fun OnboardingScreen(
    onComplete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val permissions = remember {
        buildList {
            add(PermissionItem(
                id = "mic", title = "麦克风",
                description = "让灵犀能听到你说话",
                icon = Icons.Outlined.Mic,
                androidPermission = Manifest.permission.RECORD_AUDIO,
                accentColor = Color(0xFF00D4FF)
            ))
            add(PermissionItem(
                id = "camera", title = "相机",
                description = "让灵犀能看到你所看到的",
                icon = Icons.Outlined.CameraAlt,
                androidPermission = Manifest.permission.CAMERA,
                accentColor = Color(0xFF7B61FF)
            ))
            add(PermissionItem(
                id = "contacts", title = "通讯录",
                description = "让灵犀能帮你给联系人发消息",
                icon = Icons.Outlined.Contacts,
                androidPermission = Manifest.permission.READ_CONTACTS,
                accentColor = Color(0xFF00E676)
            ))
            add(PermissionItem(
                id = "storage", title = "存储",
                description = "让灵犀能保存你的作品",
                icon = Icons.Outlined.Storage,
                androidPermission = if (Build.VERSION.SDK_INT >= 33)
                    Manifest.permission.READ_MEDIA_IMAGES
                else
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                accentColor = Color(0xFF26C6DA)
            ))
            add(PermissionItem(
                id = "sms", title = "短信",
                description = "让灵犀能替你发送短信",
                icon = Icons.Outlined.Sms,
                androidPermission = Manifest.permission.SEND_SMS,
                accentColor = Color(0xFFFFB74D)
            ))
            if (Build.VERSION.SDK_INT >= 33) {
                add(PermissionItem(
                    id = "post_notifications", title = "通知（推送）",
                    description = "让灵犀能向你发送提醒",
                    icon = Icons.Outlined.Notifications,
                    androidPermission = Manifest.permission.POST_NOTIFICATIONS,
                    accentColor = Color(0xFFFF8A65)
                ))
            }
            add(PermissionItem(
                id = "accessibility", title = "无障碍",
                description = "让灵犀能在屏幕上为你指引",
                icon = Icons.Outlined.Accessibility,
                isSpecial = true,
                settingsAction = Settings.ACTION_ACCESSIBILITY_SETTINGS,
                accentColor = Color(0xFFFF6B9D)
            ))
            add(PermissionItem(
                id = "overlay", title = "悬浮窗",
                description = "让灵犀能悬浮在其他应用上方",
                icon = Icons.Outlined.Layers,
                isSpecial = true,
                settingsAction = Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                accentColor = Color(0xFFFF5252)
            ))
            add(PermissionItem(
                id = "notifications", title = "通知使用权",
                description = "让灵犀能管理通知",
                icon = Icons.Outlined.Notifications,
                isSpecial = true,
                settingsAction = Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS,
                accentColor = Color(0xFFFFD54F)
            ))
        }
    }

    // Track granted state
    val grantedState = remember {
        mutableStateMapOf<String, Boolean>().apply {
            permissions.forEach { put(it.id, checkPermission(context, it)) }
        }
    }

    // Poll on resume for special permissions
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                permissions.forEach { perm ->
                    grantedState[perm.id] = checkPermission(context, perm)
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Runtime permission launcher
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        // Refresh all states
        permissions.forEach { perm ->
            grantedState[perm.id] = checkPermission(context, perm)
        }
    }

    // Ambient background
    val infiniteTransition = rememberInfiniteTransition(label = "onboardingBg")
    val glowOffset by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(5000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ), label = "bgGlow"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .inkPageBackground()
    ) {
        // Ambient gradient
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            DiaAccentSecondary.copy(alpha = 0.05f),
                            Color.Transparent
                        ),
                        center = Offset(300f, 300f + glowOffset * 80f),
                        radius = 500f
                    )
                )
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.navigationBars),
            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Mascot + greeting
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    DiaLogo(size = 100.dp)

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "你好，我是灵犀",
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = (-0.5).sp
                        ),
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "我需要一些权限来帮助你",
                        style = MaterialTheme.typography.bodyLarge,
                        color = DiaTextSecondary
                    )
                }
            }

            // Permission cards
            items(permissions, key = { it.id }) { perm ->
                val isGranted = grantedState[perm.id] == true

                PermissionCard(
                    item = perm,
                    isGranted = isGranted,
                    onClick = {
                        if (!isGranted) {
                            if (perm.isSpecial) {
                                val intent = Intent(perm.settingsAction)
                                if (perm.settingsAction == Settings.ACTION_MANAGE_OVERLAY_PERMISSION) {
                                    intent.data = Uri.parse("package:${context.packageName}")
                                }
                                context.startActivity(intent)
                            } else {
                                perm.androidPermission?.let { permissionLauncher.launch(it) }
                            }
                        }
                    }
                )
            }

            // Continue button
            item {
                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = onComplete,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DiaAccent,
                        contentColor = DiaBackground
                    )
                ) {
                    Text(
                        text = "继续",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "你可以随时在设置中更改这些权限",
                    style = MaterialTheme.typography.bodySmall,
                    color = DiaTextTertiary,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun PermissionCard(
    item: PermissionItem,
    isGranted: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val statusColor by animateColorAsState(
        targetValue = if (isGranted) DiaSuccess else DiaWarning,
        animationSpec = tween(300),
        label = "statusColor"
    )

    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick),
        cornerRadius = 20.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon with glow
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .iconGlow(
                        color = if (isGranted) DiaSuccess else item.accentColor,
                        alpha = if (isGranted) 0.2f else 0.3f,
                        radius = 50f
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isGranted) Icons.Rounded.CheckCircle else item.icon,
                    contentDescription = item.title,
                    tint = if (isGranted) DiaSuccess else item.accentColor,
                    modifier = Modifier.size(26.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Text
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = Color.White
                )
                Text(
                    text = item.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = DiaTextSecondary
                )
            }

            // Status
            if (isGranted) {
                Text(
                    text = "已授权",
                    style = MaterialTheme.typography.labelSmall,
                    color = DiaSuccess
                )
            } else {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(item.accentColor.copy(alpha = 0.1f))
                        .border(
                            width = 1.dp,
                            color = item.accentColor.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(8.dp)
                        )
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (item.isSpecial) "打开" else "允许",
                            style = MaterialTheme.typography.labelSmall,
                            color = item.accentColor
                        )
                        if (item.isSpecial) {
                            Icon(
                                imageVector = Icons.Rounded.ChevronRight,
                                contentDescription = null,
                                tint = item.accentColor,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun checkPermission(context: Context, item: PermissionItem): Boolean {
    return when {
        item.isSpecial && item.settingsAction == Settings.ACTION_MANAGE_OVERLAY_PERMISSION -> {
            Settings.canDrawOverlays(context)
        }
        item.isSpecial && item.settingsAction == Settings.ACTION_ACCESSIBILITY_SETTINGS -> {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                ?.contains(context.packageName) == true
        }
        item.isSpecial && item.settingsAction == Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS -> {
            Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
                ?.contains(context.packageName) == true
        }
        item.androidPermission != null -> {
            ContextCompat.checkSelfPermission(
                context, item.androidPermission
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        else -> false
    }
}
