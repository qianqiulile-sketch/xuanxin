package com.dia.app.ui.slate

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.NavigateBefore
import androidx.compose.material.icons.automirrored.rounded.NavigateNext
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.GridOn
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dia.app.llm.DiaEngine
import com.dia.app.slate.AiInkColor
import com.dia.app.slate.AiNote
import com.dia.app.slate.AiStatus
import com.dia.app.slate.HandwritingSynth
import com.dia.app.slate.NotebookMode
import com.dia.app.slate.NotebookPage
import com.dia.app.slate.PageBackground
import com.dia.app.slate.SlateAi
import com.dia.app.slate.SlateState
import com.dia.app.slate.SlateStore
import com.dia.app.slate.estimateLineHeight
import com.dia.app.slate.pickAiAnchor
import com.dia.app.ui.theme.DiaBackground
import com.dia.app.ui.theme.inkPageBackground
import com.dia.app.ui.theme.DiaSurface
import com.dia.app.ui.theme.DiaTextPrimary
import com.dia.app.ui.theme.DiaTextSecondary
import com.dia.app.ui.theme.DiaTextTertiary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * One notebook open for editing. Page-by-page navigation via prev/next
 * buttons; new pages append on demand. Tap "Ask Dia" to send the current
 * page to Gemma; the reply is animated back as handwritten ink on the
 * SAME page just below the user's writing.
 *
 * Persistence: autosaves on stroke end, page change, AI reply commit, and
 * onDispose. Uses [SlateStore] for IO.
 */
@Composable
fun SlateNotebookScreen(notebookId: String, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var state by remember { mutableStateOf<SlateState?>(null) }

    // Load (or create empty stub if missing) the notebook on first compose.
    LaunchedEffect(notebookId) {
        val loaded = SlateStore.load(notebookId)
        state = loaded ?: SlateState(notebookId, "笔记本", NotebookMode.NOTES).also { fresh ->
            fresh.addPage(
                NotebookPage(
                    id = fresh.newPageId(),
                    width = SlateState.PAGE_WIDTH,
                    height = SlateState.PAGE_HEIGHT,
                )
            )
        }
        // Ensure clean view on open — no residual zoom/pan from a previous
        // session that might cause the "ink draws away from finger" offset.
        state?.resetView()
    }

    val s = state ?: run {
        Box(Modifier.fillMaxSize().inkPageBackground(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = DiaTextSecondary)
        }
        return
    }

    // Autosave on dispose.
    DisposableEffect(s.id) {
        onDispose {
            scope.launch(Dispatchers.IO) { SlateStore.save(s) }
        }
    }

    val page = s.currentPage ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .inkPageBackground()
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars),
    ) {
        TopBar(
            state = s,
            onBack = onBack,
            onDelete = {
                scope.launch {
                    SlateStore.delete(s.id)
                    onBack()
                }
            },
        )

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
        ) {
            PageCanvas(state = s, page = page)

            // Page indicator (top-center).
            PageIndicator(
                currentIndex = s.currentPageIndex,
                total = s.pages.size,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 8.dp),
            )

            // AI status pill (top-center, below page indicator).
            if (page.aiStatus != AiStatus.IDLE) {
                Row(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 44.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.Black.copy(alpha = 0.55f))
                        .border(1.dp, AiInkColor.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    if (page.aiStatus == AiStatus.ASKING) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(12.dp),
                            color = AiInkColor,
                            strokeWidth = 1.6.dp,
                        )
                    }
                    Text(
                        when (page.aiStatus) {
                            AiStatus.ASKING -> "Gemma 4 正在阅读…"
                            AiStatus.ERROR -> page.aiStatusText.ifBlank { "无法连接到模型" }
                            else -> ""
                        },
                        color = if (page.aiStatus == AiStatus.ERROR) Color(0xFFFF5252) else AiInkColor,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                    )
                }
            }
        }

        // Action row — sits BELOW the canvas. Prev / Ask Dia / Next.
        // Sibling to the canvas Box so its touches never compete.
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            NotebookNavButton(
                icon = Icons.AutoMirrored.Rounded.NavigateBefore,
                contentDesc = "上一页",
                enabled = s.currentPageIndex > 0,
            ) {
                scope.launch(Dispatchers.IO) { SlateStore.save(s) }
                s.currentPageIndex = (s.currentPageIndex - 1).coerceAtLeast(0)
                s.resetView()
            }
            Spacer(Modifier.weight(1f))
            AskDiaFab(
                state = s,
                page = page,
                onAsk = {
                    askDiaForPage(s, page, scope) {
                        scope.launch(Dispatchers.IO) { SlateStore.save(s) }
                    }
                },
            )
            Spacer(Modifier.weight(1f))
            NotebookNavButton(
                icon = if (s.currentPageIndex == s.pages.size - 1)
                    Icons.Rounded.Add
                else
                    Icons.AutoMirrored.Rounded.NavigateNext,
                contentDesc = if (s.currentPageIndex == s.pages.size - 1) "添加页面" else "下一页",
                enabled = true,
            ) {
                scope.launch(Dispatchers.IO) { SlateStore.save(s) }
                val last = s.pages.size - 1
                if (s.currentPageIndex == last) {
                    s.addPage(
                        NotebookPage(
                            id = s.newPageId(),
                            width = SlateState.PAGE_WIDTH,
                            height = SlateState.PAGE_HEIGHT,
                        )
                    )
                }
                s.currentPageIndex = (s.currentPageIndex + 1).coerceAtMost(s.pages.size - 1)
                s.resetView()
            }
        }

        SlateToolbar(state = s)
    }
}

@Composable
private fun TopBar(state: SlateState, onBack: () -> Unit, onDelete: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回", tint = DiaTextSecondary)
        }
        Spacer(Modifier.width(4.dp))
        // Editable title.
        BasicTextField(
            value = state.title,
            onValueChange = { state.title = it },
            singleLine = true,
            cursorBrush = SolidColor(AiInkColor),
            textStyle = TextStyle(
                color = DiaTextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
            ),
            modifier = Modifier.weight(1f),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { /* leave, autosave on dispose */ }),
        )

        // Background cycle.
        IconButton(onClick = {
            state.pageBackground = when (state.pageBackground) {
                PageBackground.RULED -> PageBackground.GRID
                PageBackground.GRID -> PageBackground.DOTS
                PageBackground.DOTS -> PageBackground.PLAIN
                PageBackground.PLAIN -> PageBackground.RULED
            }
        }) {
            Icon(Icons.Rounded.GridOn, "页面背景", tint = DiaTextSecondary)
        }

        // Undo (current page only).
        IconButton(onClick = { state.currentPage?.undo() }) {
            Icon(Icons.AutoMirrored.Rounded.Undo, "撤销", tint = DiaTextSecondary)
        }

        // Clear current page.
        IconButton(onClick = { state.currentPage?.clearAll() }) {
            Icon(Icons.Rounded.DeleteOutline, "清空页面", tint = DiaTextSecondary)
        }
    }
}

@Composable
private fun NotebookNavButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDesc: String,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    IconButton(
        onClick = { if (enabled) onClick() },
        modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = if (enabled) 0.55f else 0.25f))
            .border(1.dp, Color.White.copy(alpha = 0.12f), CircleShape),
    ) {
        Icon(
            icon,
            contentDesc,
            tint = if (enabled) Color.White.copy(alpha = 0.9f) else Color.White.copy(alpha = 0.3f),
        )
    }
}

@Composable
private fun AskDiaFab(
    state: SlateState,
    page: NotebookPage,
    modifier: Modifier = Modifier,
    onAsk: () -> Unit,
) {
    val enabled = page.aiStatus == AiStatus.IDLE && page.strokes.isNotEmpty()
    val busy = page.aiStatus == AiStatus.ASKING
    val bg = if (enabled || busy) Color(0xFF7AD8FF) else Color(0xFF272733)
    val tint = if (enabled || busy) Color(0xFF0A0B11) else DiaTextTertiary
    Box(
        modifier = modifier
            .size(58.dp)
            .clip(CircleShape)
            .background(bg)
            .border(2.dp, Color.White.copy(alpha = 0.2f), CircleShape),
    ) {
        IconButton(
            onClick = { if (enabled) onAsk() },
            modifier = Modifier.fillMaxSize(),
        ) {
            if (busy) {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    color = Color(0xFF0A0B11),
                    strokeWidth = 2.5.dp,
                )
            } else {
                Icon(Icons.Rounded.AutoAwesome, "问问灵犀", tint = tint)
            }
        }
    }
}

/* ─── Inference flow ─── */

private fun askDiaForPage(
    state: SlateState,
    page: NotebookPage,
    scope: kotlinx.coroutines.CoroutineScope,
    onCommitted: () -> Unit,
) {
    if (page.aiStatus != AiStatus.IDLE) return
    page.aiStatus = AiStatus.ASKING
    page.aiStatusText = ""

    DiaEngine.cancelPilotSession()

    // Slate's vision model works best on the local Gemma (multimodal,
    // tuned prompts, no network latency). Force LOCAL regardless of the
    // user's cloud setting — cloud text-only endpoints can't even see
    // the bitmap.
    com.dia.app.llm.BackendRouter.sessionOverride = com.dia.app.llm.BackendRouter.Backend.LOCAL

    scope.launch(Dispatchers.Main) {
        delay(150)  // let any prior session settle
        SlateAi.askNotes(page, scope) { reply ->
            // Clear the override so other features respect the user's setting.
            com.dia.app.llm.BackendRouter.sessionOverride = null

            if (reply.isNullOrBlank()) {
                page.aiStatus = AiStatus.ERROR
                page.aiStatusText = "无法识别页面内容，请尝试写大一些。"
                scope.launch {
                    delay(2400)
                    if (page.aiStatus == AiStatus.ERROR) page.aiStatus = AiStatus.IDLE
                }
                return@askNotes
            }

            // Synthesise handwriting and animate it onto the page.
            val lineHeight = estimateLineHeight(page)
            val anchor = pickAiAnchor(page)
            // Constrain to the page width minus margin.
            val maxWidth = (page.width - anchor.x - 80f).coerceAtLeast(200f)
            val maxBottom = page.height - 80f
            val strokes = HandwritingSynth.synthesize(
                text = reply,
                anchor = anchor,
                lineHeight = lineHeight,
                maxWidth = maxWidth,
                color = AiInkColor,
                maxBottomY = maxBottom,
            )
            if (strokes.isEmpty()) {
                page.aiStatus = AiStatus.IDLE
                return@askNotes
            }

            // Pin the typed reply too (so it survives reload + serialises cheaply).
            page.addAiNote(AiNote(id = state.newNoteId(), text = reply, anchor = anchor))

            scope.launch(Dispatchers.Main) {
                try {
                    SlateAi.animateStrokes(strokes, state, page)
                } finally {
                    page.aiStatus = AiStatus.IDLE
                    onCommitted()
                }
            }
        }
    }
}
