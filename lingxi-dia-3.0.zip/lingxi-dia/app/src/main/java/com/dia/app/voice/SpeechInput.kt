package com.dia.app.voice

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 语音转文字（系统语音识别）。
 *
 * 用户说话 → 转成文字 → 当作普通文字消息发给 AI → AI 用文字回复（语音对话模式下再朗读）。
 * 本地模型和云端模型都能用；设备没有语音识别服务时，界面会退回「录音交给本机 Gemma 听」。
 * 只在用户按下麦克风时识别一句话，说完即停。
 */
class SpeechInput(private val context: Context) {

    enum class State { IDLE, LISTENING, PROCESSING }

    private val _state = MutableStateFlow(State.IDLE)
    val state: StateFlow<State> = _state.asStateFlow()

    private val _partial = MutableStateFlow("")
    val partial: StateFlow<String> = _partial.asStateFlow()

    /** 0..1 的音量，用来画声波。 */
    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level.asStateFlow()

    private var recognizer: SpeechRecognizer? = null
    private var onResult: ((String) -> Unit)? = null
    private var onError: ((String) -> Unit)? = null

    fun isAvailable(): Boolean = try {
        SpeechRecognizer.isRecognitionAvailable(context) ||
            (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(context))
    } catch (_: Exception) {
        false
    }

    private fun create(): SpeechRecognizer? = try {
        when {
            SpeechRecognizer.isRecognitionAvailable(context) -> SpeechRecognizer.createSpeechRecognizer(context)
            Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(context) ->
                SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
            else -> null
        }
    } catch (e: Exception) {
        Log.w("SpeechInput", "create failed: ${e.message}")
        null
    }

    /** 开始听一句话。必须在主线程调用。 */
    fun start(language: String, onResult: (String) -> Unit, onError: (String) -> Unit) {
        cancel()
        val r = create() ?: run { onError("这台手机没有可用的语音识别服务"); return }
        recognizer = r
        this.onResult = onResult
        this.onError = onError
        _partial.value = ""
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { _state.value = State.LISTENING }
            override fun onBeginningOfSpeech() { _state.value = State.LISTENING }
            override fun onRmsChanged(rmsdB: Float) { _level.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { _state.value = State.PROCESSING; _level.value = 0f }
            override fun onError(error: Int) {
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "没有听清，请再说一遍"
                    SpeechRecognizer.ERROR_AUDIO -> "录音出错"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "需要麦克风权限"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "语音识别需要联网（或在系统设置里下载离线语音包）"
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "语音识别正忙，请稍后"
                    else -> "语音识别失败（$error）"
                }
                // 识别失败但已经有部分结果：直接用部分结果
                val p = _partial.value
                val cb = this@SpeechInput.onResult
                val eb = this@SpeechInput.onError
                finish()
                if (p.isNotBlank() && (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)) {
                    cb?.invoke(p)
                } else eb?.invoke(msg)
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    .ifBlank { _partial.value }
                val cb = this@SpeechInput.onResult
                val eb = this@SpeechInput.onError
                finish()
                if (text.isNotBlank()) cb?.invoke(text) else eb?.invoke("没有听清，请再说一遍")
            }
            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    ?.takeIf { it.isNotBlank() }?.let { _partial.value = it }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
        _state.value = State.LISTENING
        try {
            r.startListening(intent)
        } catch (e: Exception) {
            finish()
            onError("无法启动语音识别：${e.message}")
        }
    }

    /** 说完了：停止录音，等待最终结果。 */
    fun stop() {
        if (_state.value == State.LISTENING) {
            _state.value = State.PROCESSING
            try { recognizer?.stopListening() } catch (_: Exception) { }
        }
    }

    fun cancel() {
        try { recognizer?.cancel() } catch (_: Exception) { }
        finish()
    }

    private fun finish() {
        try { recognizer?.destroy() } catch (_: Exception) { }
        recognizer = null
        onResult = null
        onError = null
        _state.value = State.IDLE
        _level.value = 0f
    }

    fun release() = cancel()
}
