package com.dia.app.pilot.tool.impl

import com.dia.app.pilot.tool.BaseTool
import com.dia.app.pilot.tool.ToolParameter
import com.dia.app.pilot.tool.ToolResult

class TapTool : BaseTool() {
    override fun getName(): String = "tap"

    override fun getDescription(): String = "Tap at screen coordinates (x, y)."

    override fun getParameters(): List<ToolParameter> = listOf(
        ToolParameter("x", "integer", "X coordinate on screen", true),
        ToolParameter("y", "integer", "Y coordinate on screen", true),
    )

    override fun execute(params: Map<String, Any>): ToolResult {
        return try {
            val service = requireAccessibilityService() ?: return ToolResult.error("Accessibility service is not running")
            val x = requireInt(params, "x")
            val y = requireInt(params, "y")
            val success = service.performTap(x, y)
            return if (success) ToolResult.success("Tapped at ($x, $y)")
            else ToolResult.error("Failed to tap at ($x, $y)")
        } catch (e: Exception) {
            ToolResult.error("Tap error: ${e.message}")
        }
    }
}
