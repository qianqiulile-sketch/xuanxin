package com.dia.app.ui.guide

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dia.app.DiaAccessibilityService
import com.dia.app.guide.GuideEngine
import com.dia.app.guide.GuideOverlayService
import com.dia.app.guide.GuideState
import com.dia.app.ui.theme.DiaBackground
import com.dia.app.ui.theme.inkPageBackground
import com.dia.app.ui.theme.DiaGuideColor
import com.dia.app.ui.theme.DiaSurface
import com.dia.app.ui.theme.DiaTextPrimary
import com.dia.app.ui.theme.DiaTextSecondary
import com.dia.app.ui.theme.DiaTextTertiary

private val QUICK_PROMPTS = listOf(
    "演示一下灵犀怎么用",
    "设置在哪里",
    "怎么更换壁纸",
    "怎么在微信里发照片",
    "打开蓝牙",
)

@Composable
fun GuideScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var question by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        GuideEngine.attach(context)
    }

    val state by GuideEngine.state.collectAsState()
    val step by GuideEngine.currentStep.collectAsState()
    val guide by GuideEngine.guide.collectAsState()
    val isRunning = state != GuideState.IDLE

    val a11yReady = DiaAccessibilityService.isRunning()
    val overlayReady = GuideOverlayService.hasOverlayPermission(context)
    val scrollState = rememberScrollState()

    // Voice input — same pattern as Slate so the user can speak the goal.
    var isListening by remember { mutableStateOf(false) }
    val speechRecognizer = remember {
        if (android.speech.SpeechRecognizer.isRecognitionAvailable(context))
            android.speech.SpeechRecognizer.createSpeechRecognizer(context)
        else null
    }
    val recognizerIntent = remember {
        android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM,
            )
            putExtra(
                android.speech.RecognizerIntent.EXTRA_LANGUAGE,
                "zh-CN",
            )
        }
    }
    DisposableEffect(Unit) {
        speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(p: android.os.Bundle?) { isListening = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(p: Float) {}
            override fun onBufferReceived(p: ByteArray?) {}
            override fun onEndOfSpeech() { isListening = false }
            override fun onError(e: Int) { isListening = false }
            override fun onResults(results: android.os.Bundle?) {
                isListening = false
                val text = results?.getStringArrayList(
                    android.speech.SpeechRecognizer.RESULTS_RECOGNITION
                )?.firstOrNull()
                if (!text.isNullOrBlank()) {
                    question = text
                }
            }
            override fun onPartialResults(p: android.os.Bundle?) {}
            override fun onEvent(p: Int, q: android.os.Bundle?) {}
        })
        onDispose { speechRecognizer?.destroy() }
    }

    // Auto-start listening when screen opens if preference is enabled.
    LaunchedEffect(Unit) {
        if (com.dia.app.prefs.DiaPrefs.autoListen.value) {
            kotlinx.coroutines.delay(500)
            try { speechRecognizer?.startListening(recognizerIntent) } catch (_: Exception) {}
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .inkPageBackground()
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回", tint = DiaTextSecondary)
            }
            Spacer(Modifier.width(6.dp))
            Column {
                Text("指南", style = MaterialTheme.typography.titleLarge, color = DiaTextPrimary)
                Text("我来告诉你该点哪里", style = MaterialTheme.typography.bodySmall, color = DiaTextSecondary)
            }
            Spacer(Modifier.weight(1f))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (isRunning) DiaGuideColor.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.06f))
                    .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    when (state) {
                        GuideState.IDLE -> "空闲"
                        GuideState.ANALYZING -> "分析中"
                        GuideState.GUIDING -> "指引中"
                        GuideState.PAUSED -> "已暂停"
                        GuideState.COMPLETE -> "完成"
                    },
                    color = if (isRunning) DiaGuideColor else DiaTextSecondary,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }

        // Permission warnings
        if (!a11yReady) {
            WarningCard(
                title = "需要无障碍权限",
                body = "请在无障碍设置中启用灵犀，以便指南功能读取你的屏幕。",
                actionLabel = "打开设置",
                onAction = {
                    val i = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(i)
                }
            )
        }
        if (!overlayReady) {
            WarningCard(
                title = "需要悬浮窗权限",
                body = "请允许灵犀显示在其他应用上方，以便指引光标跟随你操作。",
                actionLabel = "打开设置",
                onAction = {
                    val i = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}")
                    )
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(i)
                }
            )
        }

        // Input
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(DiaSurface, RoundedCornerShape(16.dp))
                .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(16.dp))
                .padding(14.dp)
        ) {
            Text("你需要什么帮助？", color = DiaTextSecondary, style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(6.dp))
            Box(Modifier.fillMaxWidth()) {
                if (question.isEmpty()) {
                    Text(
                        "例如：怎么打开蓝牙？",
                        color = DiaTextTertiary,
                        fontSize = 13.sp
                    )
                }
                BasicTextField(
                    value = question,
                    onValueChange = { question = it },
                    textStyle = TextStyle(color = DiaTextPrimary, fontSize = 15.sp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Quick prompts
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(DiaSurface, RoundedCornerShape(16.dp))
                .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(16.dp))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("快捷提问", color = DiaTextSecondary, style = MaterialTheme.typography.labelSmall)
            QUICK_PROMPTS.forEach { p ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White.copy(alpha = 0.04f))
                        .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .clickableRow { question = p }
                ) {
                    Text(p, color = DiaTextPrimary, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        // Controls
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            val canStart = !isRunning && question.isNotBlank() && a11yReady && overlayReady
            IconButton(
                onClick = {
                    if (canStart) {
                        GuideOverlayService.start(context, question.trim())
                        val home = Intent(Intent.ACTION_MAIN).apply {
                            addCategory(Intent.CATEGORY_HOME)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(home)
                    }
                },
                enabled = canStart,
                modifier = Modifier
                    .size(56.dp)
                    .background(if (canStart) DiaGuideColor else DiaSurface, CircleShape)
            ) {
                Icon(
                    Icons.Rounded.PlayArrow,
                    "开始",
                    tint = if (canStart) Color.Black else DiaTextTertiary
                )
            }

            // Voice input — speak your question.
            IconButton(
                onClick = {
                    if (!isListening && !isRunning) {
                        try { speechRecognizer?.startListening(recognizerIntent) } catch (_: Exception) {}
                    } else if (isListening) {
                        try { speechRecognizer?.stopListening() } catch (_: Exception) {}
                    }
                },
                enabled = !isRunning,
                modifier = Modifier
                    .size(56.dp)
                    .background(
                        if (isListening) DiaGuideColor.copy(alpha = 0.85f)
                        else Color.White.copy(alpha = 0.06f),
                        CircleShape,
                    )
                    .border(
                        1.dp,
                        if (isListening) DiaGuideColor else Color.White.copy(alpha = 0.10f),
                        CircleShape,
                    ),
            ) {
                Icon(
                    Icons.Rounded.Mic,
                    contentDescription = if (isListening) "聆听中… 点击停止" else "说出你的问题",
                    tint = if (isListening) Color.Black else DiaTextPrimary,
                )
            }

            IconButton(
                onClick = {
                    GuideEngine.stop()
                    GuideOverlayService.stop(context)
                },
                enabled = isRunning,
                modifier = Modifier
                    .size(56.dp)
                    .background(if (isRunning) Color(0xFF2A2A3A) else DiaSurface, CircleShape)
            ) {
                Icon(Icons.Rounded.Stop, "停止", tint = if (isRunning) DiaTextPrimary else DiaTextTertiary)
            }

            Spacer(Modifier.weight(1f))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White.copy(alpha = 0.05f))
                    .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text(
                    text = when (state) {
                        GuideState.GUIDING -> step?.let { "第 ${it.stepNumber}/${it.totalSteps} 步" } ?: "指引中"
                        GuideState.ANALYZING -> "规划中…"
                        GuideState.COMPLETE -> "全部完成"
                        GuideState.PAUSED -> "已暂停"
                        GuideState.IDLE -> "就绪"
                    },
                    color = DiaTextSecondary,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }

        // Active tutorial summary
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(DiaSurface, RoundedCornerShape(16.dp))
                .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(16.dp))
                .padding(14.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("步骤计划", color = DiaTextSecondary, style = MaterialTheme.typography.labelSmall)
            val active = guide
            if (active == null) {
                Text(
                    "提出问题后，灵犀会在你打开的任何应用上方显示指引光标和说明文字。",
                    color = DiaTextTertiary,
                    style = MaterialTheme.typography.bodySmall
                )
            } else {
                active.steps.forEach { s ->
                    val isCurrent = step?.stepNumber == s.stepNumber
                    val color = if (isCurrent) DiaGuideColor else DiaTextPrimary
                    Text(
                        "${s.stepNumber}. ${s.caption}",
                        color = color,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            // Powered-by footer
            Text(
                "由 Gemma 4 驱动 · 端侧运行",
                color = DiaTextTertiary.copy(alpha = 0.4f),
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
        }
    }
}

private fun Modifier.clickableRow(onClick: () -> Unit): Modifier =
    this.then(Modifier.clickable(onClick = onClick))

@Composable
private fun WarningCard(title: String, body: String, actionLabel: String, onAction: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DiaSurface, RoundedCornerShape(16.dp))
            .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Text(title, color = DiaTextPrimary, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        Text(body, color = DiaTextSecondary)
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = onAction,
                modifier = Modifier
                    .size(42.dp)
                    .background(DiaGuideColor, CircleShape)
            ) {
                Icon(Icons.Rounded.PlayArrow, "打开", tint = Color.Black)
            }
            Spacer(Modifier.width(8.dp))
            Text(actionLabel, color = DiaTextSecondary, modifier = Modifier.align(Alignment.CenterVertically))
        }
    }
}
