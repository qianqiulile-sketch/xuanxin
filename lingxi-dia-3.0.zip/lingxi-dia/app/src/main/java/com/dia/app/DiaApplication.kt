package com.dia.app

import android.app.Application
import com.dia.app.files.FileManager
import com.dia.app.imagegen.ImageGen
import com.dia.app.memory.MemoryStore
import com.dia.app.prefs.DiaPrefs
import com.dia.app.prefs.DiaSettings
import com.dia.app.screen.BubbleConfig
import com.dia.app.ui.chat.ChatController

class DiaApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        DiaPrefs.init(this)
        DiaSettings.init(this)
        BubbleConfig.init(this)
        MemoryStore.init(this)
        FileManager.init(this)
        ImageGen.init(this)
        ChatController.attach(this)
    }
}
