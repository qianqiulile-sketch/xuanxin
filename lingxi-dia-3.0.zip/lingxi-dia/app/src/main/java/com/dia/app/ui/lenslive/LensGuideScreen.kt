package com.dia.app.ui.lenslive

import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Cameraswitch
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.dia.app.llm.BackendRouter
import com.dia.app.llm.DiaEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

private const val TAG = "LensGuideScreen"

private val GuideAccent = Color(0xFF29B6F6)

/**
 * Lens Live Guide — image-grounded "where is X / how do I X" assistant.
 *
 * Design principles:
 *  - One persistent input row at the bottom: text field + mic + send. No
 *    modal "voice mode vs text mode" — both are always available.
 *  - Transcript renders top-down like a chat, with the latest message at
 *    the bottom (LazyColumn auto-scrolls).
 *  - Bounding-box overlay points at whatever Gemma identified, drawn over
 *    the live preview.
 *  - Stop / TTS / camera-flip toggles in the HUD; nothing more.
 *  - No surrounding chrome (no pinned banner, no suggestion chips). Just
 *    transcript + input — keeps the camera as the centerpiece.
 */
@Composable
fun LensGuideScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current

    // ── State ──
    var uiState by remember { mutableStateOf<LensLiveUiState>(LensLiveUiState.Initializing) }
    val transcript = remember { mutableStateListOf<TranscriptEntry>() }
    var currentResponse by remember { mutableStateOf("") }
    var inputText by remember { mutableStateOf("") }
    var useFrontCamera by remember { mutableStateOf(false) }
    var ttsEnabled by remember { mutableStateOf(true) }
    var inflightJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    val queryInFlight = remember { AtomicBoolean(false) }

    val imageCapture = remember {
        ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
    }
    val captureExecutor = remember { Executors.newSingleThreadExecutor() }

    // ── Bounding box state ──
    var focusBounds by remember { mutableStateOf<List<Float>?>(null) }
    var lastFrameSize by remember { mutableStateOf<IntSize?>(null) }
    var showSpotlight by remember { mutableStateOf(false) }
    // Frozen frame — only shown WHILE a bounding box is up so the box
    // points at the actual pixels Gemma reasoned about. Cleared once the
    // user dismisses the box or asks a new question.
    var frozenFrame by remember { mutableStateOf<Bitmap?>(null) }

    // ── TTS ──
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsReady by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        val engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.language = Locale.SIMPLIFIED_CHINESE
                tts?.setSpeechRate(1.05f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        if (uiState is LensLiveUiState.Speaking) uiState = LensLiveUiState.Conversing("")
                    }
                    @Deprecated("Deprecated in API")
                    override fun onError(utteranceId: String?) {
                        if (uiState is LensLiveUiState.Speaking) uiState = LensLiveUiState.Conversing("")
                    }
                })
            }
        }
        tts = engine
        onDispose { engine.stop(); engine.shutdown() }
    }

    // ── Speech Recognition ──
    val recognizerIntent = remember {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "zh-CN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
    }
    val speechRecognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(context))
            SpeechRecognizer.createSpeechRecognizer(context)
        else null
    }

    /** Helper that fires off [doGuide] with all the captured state. */
    val sendGuideQuestion: (String) -> Unit = label@{ question ->
        val q = question.trim()
        if (q.isEmpty() || queryInFlight.get()) return@label
        focusBounds = null
        frozenFrame = null
        inflightJob = doGuide(
            question = q,
            isFirstTurn = transcript.none { it.role == "user" },
            queryInFlight = queryInFlight,
            tts = tts.takeIf { ttsEnabled && ttsReady },
            imageCapture = imageCapture,
            captureExecutor = captureExecutor,
            useFrontCamera = useFrontCamera,
            onStateChange = { uiState = it },
            onResponseUpdate = { currentResponse = it },
            transcript = transcript,
            scope = scope,
            onFocusBoundsUpdate = { focusBounds = it },
            onFrameSizeUpdate = { lastFrameSize = it },
            onFrameCaptured = { frozenFrame = it },
        )
    }

    DisposableEffect(Unit) {
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { uiState = LensLiveUiState.Listening }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                if (uiState is LensLiveUiState.Listening) uiState = LensLiveUiState.Scanning
            }
            override fun onError(error: Int) {
                Log.e(TAG, "Speech recognition error: $error")
                if (uiState is LensLiveUiState.Listening) uiState = LensLiveUiState.Scanning
            }
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val voicePrompt = matches?.firstOrNull()
                if (!voicePrompt.isNullOrBlank()) {
                    sendGuideQuestion(voicePrompt)
                } else {
                    uiState = LensLiveUiState.Scanning
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {
                // Surface partials live in the input field so the user
                // can confirm we're hearing them.
                val partial = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (!partial.isNullOrBlank()) inputText = partial
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        onDispose { speechRecognizer?.destroy() }
    }

    // ── Camera (bind once) ──
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }
    val cameraPermissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { granted -> hasCameraPermission = granted }

    var cameraProvider by remember { mutableStateOf<ProcessCameraProvider?>(null) }
    val previewView = remember {
        PreviewView(context).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
    }
    LaunchedEffect(Unit) {
        if (hasCameraPermission) {
            val future = ProcessCameraProvider.getInstance(context)
            future.addListener({ cameraProvider = future.get() }, ContextCompat.getMainExecutor(context))
        } else {
            cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
        }
    }
    LaunchedEffect(hasCameraPermission) {
        if (hasCameraPermission && cameraProvider == null) {
            val future = ProcessCameraProvider.getInstance(context)
            future.addListener({ cameraProvider = future.get() }, ContextCompat.getMainExecutor(context))
        }
    }
    LaunchedEffect(cameraProvider, useFrontCamera) {
        val provider = cameraProvider ?: return@LaunchedEffect
        val selector = if (useFrontCamera) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
        try {
            provider.unbindAll()
            provider.bindToLifecycle(lifecycleOwner, selector, preview, imageCapture)
        } catch (e: Exception) {
            Log.e(TAG, "Camera bind failed", e)
        }
        if (uiState is LensLiveUiState.Initializing) uiState = LensLiveUiState.Scanning
    }

    LaunchedEffect(uiState, focusBounds) {
        showSpotlight = focusBounds != null && uiState !is LensLiveUiState.Initializing
    }

    DisposableEffect(Unit) {
        onDispose {
            cameraProvider?.unbindAll()
            tts?.stop()
            DiaEngine.cancelLensQuery()
            queryInFlight.set(false)
        }
    }

    // ── Animation values ──
    val stateColor = when (uiState) {
        is LensLiveUiState.Listening -> Color(0xFFEF5350)
        is LensLiveUiState.Thinking -> GuideAccent
        is LensLiveUiState.Speaking, is LensLiveUiState.Conversing -> Color(0xFF7AD8FF)
        is LensLiveUiState.Scanning -> Color(0xFF4ADE80)
        else -> Color(0xFF3A3D46)
    }
    val stateLabel = when (uiState) {
        is LensLiveUiState.Initializing -> "启动中…"
        is LensLiveUiState.Scanning -> "就绪"
        is LensLiveUiState.Listening -> "聆听中…"
        is LensLiveUiState.Thinking -> "Gemma 4 思考中…"
        is LensLiveUiState.Speaking -> "播报中"
        is LensLiveUiState.Conversing -> "对话中"
        else -> ""
    }

    val glowTransition = rememberInfiniteTransition(label = "glow")
    val glowAlpha by glowTransition.animateFloat(
        0.1f, 0.6f,
        infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glowAlpha",
    )
    val auroraTransition = rememberInfiniteTransition(label = "aurora")
    val auroraAngle by auroraTransition.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(3000, easing = LinearEasing), RepeatMode.Restart),
        label = "auroraAngle",
    )
    val auroraIntensity by animateFloatAsState(
        targetValue = when (uiState) {
            is LensLiveUiState.Listening -> 1.0f
            is LensLiveUiState.Thinking -> 0.85f
            is LensLiveUiState.Speaking, is LensLiveUiState.Conversing -> 0.7f
            is LensLiveUiState.Scanning -> 0.25f
            else -> 0f
        },
        animationSpec = tween(500),
        label = "auroraIntensity",
    )
    val auroraActual = auroraIntensity * 0.55f

    val focusBoxAlpha by animateFloatAsState(
        targetValue = if (showSpotlight) 1f else 0f,
        animationSpec = tween(500),
        label = "focusBox",
    )
    val focusPulse by auroraTransition.animateFloat(
        0.5f, 1f,
        infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "focusPulse",
    )

    // ── UI ──
    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())

        // Freeze-frame: while a bounding box is up, paint the captured
        // frame on top of the live preview so the box lines up with the
        // pixels Gemma reasoned about. Camera keeps running underneath
        // and is revealed again as soon as the box is dismissed.
        AnimatedVisibility(
            visible = focusBounds != null && frozenFrame != null,
            enter = fadeIn(tween(180)),
            exit = fadeOut(tween(220)),
            modifier = Modifier.fillMaxSize(),
        ) {
            val bmp = frozenFrame
            if (bmp != null) {
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = "已捕获画面",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }

        // Top + bottom gradient scrims so HUD/transcript are readable.
        Box(
            modifier = Modifier
                .fillMaxWidth().height(180.dp).align(Alignment.TopCenter)
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Black.copy(alpha = 0.78f), Color.Black.copy(alpha = 0.25f), Color.Transparent)
                    )
                )
        )
        Box(
            modifier = Modifier
                .fillMaxWidth().height(360.dp).align(Alignment.BottomCenter)
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.6f), Color.Black.copy(alpha = 0.95f))
                    )
                )
        )

        AuroraBorder(auroraAngle = auroraAngle, auroraActual = auroraActual, tintColor = GuideAccent)

        // Bounding box overlay — drawn over the camera (or frozen frame),
        // under the HUD. Tap dismisses the box and drops the frozen
        // frame so the live camera shows again.
        if (focusBoxAlpha > 0.01f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {
                            focusBounds = null
                            frozenFrame = null
                        },
                    ),
            ) {
                FocusOverlay(
                    focusBounds = focusBounds,
                    lastFrameSize = lastFrameSize,
                    focusBoxAlpha = focusBoxAlpha,
                    focusPulse = focusPulse,
                )
            }
        }

        // ─── Top HUD ───
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 48.dp, start = 16.dp, end = 16.dp)
                .align(Alignment.TopStart),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            HudButton(Icons.Rounded.Close, "关闭") {
                tts?.stop()
                inflightJob?.cancel()
                DiaEngine.cancelLensQuery()
                onBack()
            }

            // State pill
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = 0.55f))
                    .border(1.dp, stateColor.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp).clip(CircleShape)
                        .background(stateColor.copy(alpha = 0.3f + glowAlpha * 0.7f))
                        .drawBehind { drawCircle(color = stateColor, radius = 3.dp.toPx()) }
                )
                Text(
                    stateLabel,
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp
                    ),
                    color = stateColor,
                )
            }

            Spacer(Modifier.weight(1f))

            // Stop (only when inflight)
            val inFlight = uiState is LensLiveUiState.Thinking || uiState is LensLiveUiState.Speaking
            if (inFlight) {
                IconButton(
                    onClick = {
                        tts?.stop()
                        inflightJob?.cancel()
                        DiaEngine.cancelLensQuery()
                        queryInFlight.set(false)
                        uiState = LensLiveUiState.Scanning
                        currentResponse = ""
                    },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFD32F2F).copy(alpha = 0.85f))
                        .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape),
                ) {
                    Icon(Icons.Rounded.Stop, "停止", tint = Color.White, modifier = Modifier.size(20.dp))
                }
            }

            // TTS toggle
            HudButton(
                if (ttsEnabled) Icons.AutoMirrored.Rounded.VolumeUp else Icons.AutoMirrored.Rounded.VolumeOff,
                if (ttsEnabled) "静音" else "取消静音",
                tint = if (ttsEnabled) Color.White.copy(alpha = 0.85f) else Color.White.copy(alpha = 0.45f),
            ) {
                ttsEnabled = !ttsEnabled
                if (!ttsEnabled) tts?.stop()
            }

            // Camera flip
            HudButton(Icons.Rounded.Cameraswitch, "切换摄像头") { useFrontCamera = !useFrontCamera }
        }

        // ─── Bottom panel: transcript + input ───
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(bottom = 28.dp, start = 12.dp, end = 12.dp),
            horizontalAlignment = Alignment.Start,
        ) {
            // Transcript — top-down, newest at the bottom.
            TranscriptList(
                transcript = transcript,
                streamingResponse = currentResponse,
                isStreaming = uiState is LensLiveUiState.Thinking,
            )

            Spacer(Modifier.height(10.dp))

            // Input row — always visible: text field + mic + send.
            GuideInputRow(
                text = inputText,
                onTextChange = { inputText = it },
                isInflight = uiState is LensLiveUiState.Thinking || uiState is LensLiveUiState.Speaking,
                onSend = {
                    val q = inputText.trim()
                    if (q.isNotEmpty()) {
                        sendGuideQuestion(q)
                        inputText = ""
                        keyboard?.hide()
                    }
                },
                isListening = uiState is LensLiveUiState.Listening,
                onMic = {
                    if (uiState is LensLiveUiState.Listening) {
                        try { speechRecognizer?.stopListening() } catch (_: Exception) {}
                    } else {
                        try {
                            speechRecognizer?.startListening(recognizerIntent)
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to start speech recognition", e)
                        }
                    }
                },
            )
        }

        if (uiState is LensLiveUiState.Initializing) InitializingOverlay()
    }
}

/* ────────────────────────────────────────────────────────────────────── */
/*  Sub-composables                                                        */
/* ────────────────────────────────────────────────────────────────────── */

@Composable
private fun HudButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDesc: String,
    tint: Color = Color.White.copy(alpha = 0.85f),
    onClick: () -> Unit,
) {
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.12f))
            .border(1.dp, Color.White.copy(alpha = 0.15f), CircleShape),
    ) {
        Icon(icon, contentDesc, tint = tint, modifier = Modifier.size(20.dp))
    }
}

/**
 * Compact transcript: only the last 2 entries (or 1 + the live stream)
 * are kept on-screen so the camera stays the centerpiece. Older messages
 * scroll off the top — the user can ask follow-ups; they don't need a
 * full chat log over the live feed.
 *
 * Streaming response is appended as the last assistant bubble while the
 * model is producing tokens.
 */
@Composable
private fun TranscriptList(
    transcript: List<TranscriptEntry>,
    streamingResponse: String,
    isStreaming: Boolean,
) {
    // Render in chronological order, keeping at most the last 2 entries
    // so the bottom panel doesn't eat the camera view. Streaming reply
    // counts as one of the slots.
    val streamingActive = streamingResponse.isNotBlank() || isStreaming
    val keepCount = if (streamingActive) 1 else 2
    val ordered = remember(transcript.size, keepCount) {
        transcript.reversed().takeLast(keepCount)
    }
    val state = rememberLazyListState()

    LaunchedEffect(transcript.size, streamingResponse, isStreaming) {
        if (ordered.isNotEmpty() || streamingResponse.isNotBlank()) {
            val target = ordered.size + if (streamingResponse.isNotBlank()) 1 else 0
            state.animateScrollToItem((target - 1).coerceAtLeast(0))
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 140.dp),
        state = state,
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        items(ordered.size) { i ->
            val entry = ordered[i]
            CaptionBubble(
                text = entry.text,
                color = if (entry.role == "user") GuideAccent else Color.White,
                isUser = entry.role == "user",
                isStreaming = false,
            )
        }
        if (streamingResponse.isNotBlank()) {
            item {
                CaptionBubble(
                    text = streamingResponse,
                    color = Color.White,
                    isUser = false,
                    isStreaming = isStreaming,
                )
            }
        }
    }
}

/**
 * Input row: text field + mic + send. The mic blinks red while listening.
 * Submitting via the IME action also fires send.
 */
@Composable
private fun GuideInputRow(
    text: String,
    onTextChange: (String) -> Unit,
    isInflight: Boolean,
    onSend: () -> Unit,
    isListening: Boolean,
    onMic: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(Color.Black.copy(alpha = 0.6f))
            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(28.dp))
            .padding(horizontal = 6.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        // Mic
        IconButton(
            onClick = onMic,
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(if (isListening) Color(0xFFEF5350) else Color.White.copy(alpha = 0.08f))
                .border(
                    1.dp,
                    if (isListening) Color(0xFFEF5350).copy(alpha = 0.6f) else Color.White.copy(alpha = 0.12f),
                    CircleShape,
                ),
        ) {
            Icon(
                Icons.Rounded.Mic, if (isListening) "停止聆听" else "语音",
                tint = if (isListening) Color.White else Color.White.copy(alpha = 0.85f),
                modifier = Modifier.size(20.dp),
            )
        }

        // Text field — sits inline, no modal swap to a separate "text mode".
        Box(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 6.dp),
        ) {
            if (text.isEmpty()) {
                Text(
                    "询问你看到的内容…",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.5f),
                )
            }
            BasicTextField(
                value = text,
                onValueChange = onTextChange,
                enabled = !isInflight,
                textStyle = TextStyle(
                    color = Color.White,
                    fontSize = 15.sp,
                    lineHeight = 22.sp,
                ),
                cursorBrush = SolidColor(GuideAccent),
                modifier = Modifier.fillMaxWidth(),
                singleLine = false,
                maxLines = 3,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { onSend() }),
            )
        }

        // Send
        IconButton(
            onClick = onSend,
            enabled = text.isNotBlank() && !isInflight,
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(
                    if (text.isNotBlank() && !isInflight) GuideAccent
                    else Color.White.copy(alpha = 0.08f)
                ),
        ) {
            Icon(
                Icons.AutoMirrored.Rounded.Send, "发送",
                tint = if (text.isNotBlank() && !isInflight) Color(0xFF0A0A0F)
                else Color.White.copy(alpha = 0.45f),
                modifier = Modifier.size(20.dp),
            )
        }
    }
}

/**
 * Bounding-box overlay drawn over the live preview. Same logic as before
 * (with normalized [BOX:x1,y1,x2,y2] coords) but isolated as its own
 * composable for readability.
 */
@Composable
private fun FocusOverlay(
    focusBounds: List<Float>?,
    lastFrameSize: IntSize?,
    focusBoxAlpha: Float,
    focusPulse: Float,
) {
    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
    ) {
        val w = size.width
        val h = size.height
        var left = w * 0.2f
        var top = h * 0.24f
        var right = w * 0.8f
        var bottom = top + (w * 0.6f)

        focusBounds?.let { b ->
            if (b.size == 4) {
                val fx1 = b[0].coerceIn(0f, 1f)
                val fy1 = b[1].coerceIn(0f, 1f)
                val fx2 = b[2].coerceIn(0f, 1f)
                val fy2 = b[3].coerceIn(0f, 1f)
                val frameSize = lastFrameSize
                if (frameSize != null) {
                    val imgW = frameSize.width.toFloat().coerceAtLeast(1f)
                    val imgH = frameSize.height.toFloat().coerceAtLeast(1f)
                    val imgAspect = imgW / imgH
                    val screenAspect = w / h
                    if (imgAspect > screenAspect) {
                        val scale = h / imgH
                        val scaledW = imgW * scale
                        val cropX = (scaledW - w) / 2f
                        left = fx1 * scaledW - cropX
                        right = fx2 * scaledW - cropX
                        top = fy1 * h
                        bottom = fy2 * h
                    } else {
                        val scale = w / imgW
                        val scaledH = imgH * scale
                        val cropY = (scaledH - h) / 2f
                        left = fx1 * w
                        right = fx2 * w
                        top = fy1 * scaledH - cropY
                        bottom = fy2 * scaledH - cropY
                    }
                } else {
                    left = fx1 * w; top = fy1 * h; right = fx2 * w; bottom = fy2 * h
                }
            }
        }

        val boxW = right - left
        val boxH = bottom - top
        val cx = (left + right) / 2f
        val cy = (top + bottom) / 2f
        val baseRadius = maxOf(boxW, boxH) * 0.55f
        val radius = baseRadius.coerceIn(24.dp.toPx(), minOf(w, h) * 0.35f)
        val ringColor = Color(0xFF4ADE80).copy(alpha = focusBoxAlpha * focusPulse)
        val glowA = (0.18f + 0.22f * focusPulse) * focusBoxAlpha

        // Dim outside the focus area
        drawRect(Color.Black.copy(alpha = 0.45f * focusBoxAlpha))
        drawCircle(
            color = Color.Transparent,
            radius = radius * 1.1f,
            center = Offset(cx, cy),
            blendMode = BlendMode.Clear,
        )

        // Soft glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(ringColor.copy(alpha = glowA), ringColor.copy(alpha = 0f)),
                center = Offset(cx, cy),
                radius = radius * 1.6f,
            ),
            radius = radius * 1.6f,
            center = Offset(cx, cy),
        )

        // Box outline
        drawRoundRect(
            color = Color(0xFF4ADE80).copy(alpha = focusBoxAlpha),
            topLeft = Offset(left, top),
            size = androidx.compose.ui.geometry.Size(boxW, boxH),
            cornerRadius = CornerRadius(12.dp.toPx(), 12.dp.toPx()),
            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round),
        )

        // Centre dot
        drawCircle(
            color = ringColor.copy(alpha = focusBoxAlpha),
            radius = 3.5.dp.toPx(),
            center = Offset(cx, cy),
        )
    }
}

/* ────────────────────────────────────────────────────────────────────── */
/*  Inference                                                              */
/* ────────────────────────────────────────────────────────────────────── */

private fun doGuide(
    question: String,
    isFirstTurn: Boolean,
    queryInFlight: AtomicBoolean,
    tts: TextToSpeech?,
    imageCapture: ImageCapture,
    captureExecutor: java.util.concurrent.Executor,
    useFrontCamera: Boolean,
    onStateChange: (LensLiveUiState) -> Unit,
    onResponseUpdate: (String) -> Unit,
    transcript: MutableList<TranscriptEntry>,
    scope: kotlinx.coroutines.CoroutineScope,
    onFocusBoundsUpdate: (List<Float>?) -> Unit,
    onFrameSizeUpdate: (IntSize) -> Unit,
    onFrameCaptured: (Bitmap?) -> Unit,
): kotlinx.coroutines.Job? {
    if (!queryInFlight.compareAndSet(false, true)) return null

    tts?.stop()
    if (isFirstTurn) DiaEngine.cancelLensQuery()

    onStateChange(LensLiveUiState.Thinking(ThinkMode.GUIDE))
    onResponseUpdate("")
    onFocusBoundsUpdate(null)

    transcript.add(0, TranscriptEntry("user", question, "guide"))

    val accumulated = StringBuilder()
    val boxRegex = Regex("\\[BOX\\s*:\\s*([0-9.]+)\\s*,\\s*([0-9.]+)\\s*,\\s*([0-9.]+)\\s*,\\s*([0-9.]+)\\s*\\]")
    var capturedFrameSize: IntSize? = null

    return scope.launch(Dispatchers.IO) {
        val frame = try {
            captureFrameScaled(imageCapture, captureExecutor, mirror = useFrontCamera)
        } catch (e: Exception) {
            Log.e(TAG, "Guide capture failed", e)
            null
        }
        if (frame != null) {
            capturedFrameSize = IntSize(frame.width, frame.height)
            scope.launch(Dispatchers.Main) {
                onFrameSizeUpdate(IntSize(frame.width, frame.height))
                onFrameCaptured(frame)
            }
        } else {
            scope.launch(Dispatchers.Main) { onFrameCaptured(null) }
        }

        BackendRouter.sendLensConversation(
            text = question,
            image = frame,
            isFirstTurn = isFirstTurn,
            cloudSystemPrompt = com.dia.app.llm.LensGuidePrompt.SYSTEM + "\nAlways reply in Simplified Chinese (简体中文), but keep any [BOX: ...] markers exactly as specified.",
            onToken = { partial, done ->
                if (!done) {
                    accumulated.append(partial)
                    var snapshot = accumulated.toString()
                    val match = boxRegex.find(snapshot)
                    if (match != null) {
                        try {
                            val bounds = match.destructured.toList().map { it.toFloat() }
                            val safe = sanitizeBounds(bounds, capturedFrameSize)
                            scope.launch(Dispatchers.Main) { onFocusBoundsUpdate(safe) }
                        } catch (_: Exception) {
                            scope.launch(Dispatchers.Main) { onFocusBoundsUpdate(null) }
                        }
                        snapshot = snapshot.replace(boxRegex, "").trimStart()
                    }
                    val cleanSnapshot = snapshot
                    scope.launch(Dispatchers.Main) { onResponseUpdate(cleanSnapshot) }
                } else {
                    queryInFlight.set(false)
                    var finalResponse = accumulated.toString()
                    val match = boxRegex.find(finalResponse)
                    if (match != null) {
                        try {
                            val bounds = match.destructured.toList().map { it.toFloat() }
                            val safe = sanitizeBounds(bounds, capturedFrameSize)
                            scope.launch(Dispatchers.Main) { onFocusBoundsUpdate(safe) }
                        } catch (_: Exception) {
                            scope.launch(Dispatchers.Main) { onFocusBoundsUpdate(null) }
                        }
                        finalResponse = finalResponse.replace(boxRegex, "").trimStart()
                    }
                    finalResponse = finalResponse.trim()

                    scope.launch(Dispatchers.Main) {
                        if (finalResponse.isNotBlank()) {
                            transcript.add(0, TranscriptEntry("assistant", finalResponse, "guide"))
                            if (tts != null) {
                                onStateChange(LensLiveUiState.Speaking(finalResponse))
                                tts.speak(finalResponse, TextToSpeech.QUEUE_FLUSH, null, "lens_guide")
                            } else {
                                onStateChange(LensLiveUiState.Conversing(question))
                            }
                            onResponseUpdate("")
                        } else {
                            onStateChange(LensLiveUiState.Scanning)
                        }
                    }
                }
            },
            onError = { msg ->
                queryInFlight.set(false)
                Log.e(TAG, "Guide error: $msg")
                scope.launch(Dispatchers.Main) {
                    onResponseUpdate("抱歉，出错了：$msg")
                    onStateChange(LensLiveUiState.Scanning)
                }
            },
        )
    }
}

private fun sanitizeBounds(values: List<Float>, frameSize: IntSize?): List<Float>? {
    if (values.size != 4) return null
    val isPercent = values.all { it in 0f..100f } && values.any { it > 1.01f }
    val hasOverOne = values.any { it > 1.01f }
    val imgW = frameSize?.width?.toFloat()?.coerceAtLeast(1f)
    val imgH = frameSize?.height?.toFloat()?.coerceAtLeast(1f)

    fun normX(v: Float): Float = when {
        isPercent -> (v / 100f).coerceIn(0f, 1f)
        hasOverOne && imgW != null -> (v / imgW).coerceIn(0f, 1f)
        else -> v.coerceIn(0f, 1f)
    }
    fun normY(v: Float): Float = when {
        isPercent -> (v / 100f).coerceIn(0f, 1f)
        hasOverOne && imgH != null -> (v / imgH).coerceIn(0f, 1f)
        else -> v.coerceIn(0f, 1f)
    }
    val left = normX(values[0])
    val top = normY(values[1])
    val right = normX(values[2])
    val bottom = normY(values[3])
    if (right <= left || bottom <= top) return null
    if (right - left < 0.02f || bottom - top < 0.02f) return null
    return listOf(left, top, right, bottom)
}
