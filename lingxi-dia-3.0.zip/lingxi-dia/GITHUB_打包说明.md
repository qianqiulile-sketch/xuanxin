# 用 GitHub 自动打包成 APK（灵犀 3.0）

> 更详细的一步步说明、以及打包脚本全文，见根目录 **`装包程序_GitHub打包APK.txt`**。命令行用户可直接运行 `一键上传GitHub.bat`（Windows）或 `一键上传GitHub.sh`（macOS / Linux）。

项目里已经带好了打包脚本 `.github/workflows/android.yml`。上传到 GitHub 后，GitHub 会在云端自动装好 JDK 17 和 Android SDK、编译，然后给你一个可以直接安装的 APK。电脑上不需要装 Android Studio。

## 一、上传代码

**方式 A：网页上传（最简单）**

1. 登录 GitHub，右上角 **＋ → New repository**，起个名字（如 `lingxi-dia`），选 Private 或 Public，点 **Create repository**。
2. 在新仓库页面点 **uploading an existing file**。
3. 把 zip **解压后**的全部文件和文件夹拖进去（注意要包含隐藏的 `.github` 文件夹；如果拖拽时丢了它，可以在网页上 **Add file → Create new file**，文件名填 `.github/workflows/android.yml`，把内容粘贴进去）。
4. 点 **Commit changes**。

**方式 B：命令行**

```bash
cd lingxi-dia            # 解压后的目录（里面已经是一个 git 仓库）
git remote add origin https://github.com/你的用户名/lingxi-dia.git
git branch -M main
git push -u origin main
```

> zip 里的 `lingxi-dia-repo.bundle` 是完整的 git 仓库（含提交记录），也可以：
> `git clone lingxi-dia-repo.bundle lingxi-dia && cd lingxi-dia`，再执行上面的 `remote add` 和 `push`。

## 二、等待打包

1. 打开仓库的 **Actions** 标签页，会看到「Android 打包」正在运行（第一次大约 8～15 分钟）。
2. 如果没有自动开始：点左侧「Android 打包」→ 右侧 **Run workflow**。
3. 运行变成绿色 ✓ 后，点进去，页面底部 **Artifacts** 里下载 `LingXi-Dia-apk`，解压得到 release（推荐，更流畅）和 debug 两个 `.apk`。

## 三、安装到手机

把 APK 传到手机安装（需要允许「安装未知来源应用」）。首次打开会有权限引导，然后进入对话页选择模型即可。

## 发布版本（可选）

给代码打一个 `v` 开头的标签并推送，会自动创建 Release 并附上 APK：

```bash
git tag v3.0.0
git push origin v3.0.0
```

## 常见问题

- **打包失败怎么办？** 点进失败的那一步看日志。脚本会先尝试带「本机生图（MediaPipe）」一起打包，失败时会自动改为不带该库再打一次（不影响在线 / 局域网生图）。如果两次都失败，把日志里第一处 `e: ` 开头的错误发给我即可定位。
- **想去掉本机生图库，减小安装包？** 把 `gradle.properties` 里的 `dia.localImageGen=true` 改成 `false`。
- **签名**：3.0 起仓库自带固定签名 `keystore/lingxi.jks`，每次打出的包签名一致，可直接覆盖升级（装过 2.0 的需先卸载一次）。如需上架应用商店，请换成你自己的正式签名。
