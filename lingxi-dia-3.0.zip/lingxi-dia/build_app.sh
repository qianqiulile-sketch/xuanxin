#!/bin/bash
# ============================================================
# Dia AI App - 一键构建脚本
# 支持 macOS / Linux
# ============================================================
set -e

echo "=========================================="
echo "   Dia AI App 构建脚本"
echo "=========================================="
echo ""

# 检查 Java 版本
JAVA_VER=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}' | cut -d'.' -f1)
echo "[1/4] 检查 Java 版本..."
if [ -z "$JAVA_VER" ]; then
    echo "  ❌ 未找到 Java，请安装 JDK 17"
    exit 1
fi
if [ "$JAVA_VER" -lt 17 ]; then
    echo "  ❌ 需要 JDK 17+，当前版本: $JAVA_VER"
    exit 1
fi
echo "  ✅ Java $JAVA_VER"

# 检查 ANDROID_HOME
echo "[2/4] 检查 Android SDK..."
if [ -z "$ANDROID_HOME" ]; then
    # 尝试常见路径
    for candidate in \
        "$HOME/Library/Android/sdk" \
        "$HOME/Android/Sdk" \
        "/opt/android-sdk" \
        "/usr/local/android-sdk"; do
        if [ -d "$candidate" ]; then
            export ANDROID_HOME="$candidate"
            break
        fi
    done
fi

if [ -z "$ANDROID_HOME" ] || [ ! -d "$ANDROID_HOME" ]; then
    echo "  ❌ 未找到 Android SDK"
    echo "  请设置 ANDROID_HOME 环境变量，或安装 Android Studio"
    echo "  macOS 默认路径: ~/Library/Android/sdk"
    exit 1
fi
echo "  ✅ Android SDK: $ANDROID_HOME"

# 构建
echo "[3/4] 构建 Debug APK..."
chmod +x ./gradlew
./gradlew assembleDebug

# 查找 APK
echo "[4/4] 定位 APK 文件..."
APK_PATH="./app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK_PATH" ]; then
    SIZE=$(du -sh "$APK_PATH" | cut -f1)
    echo ""
    echo "=========================================="
    echo "  ✅ 构建成功!"
    echo "  APK: $APK_PATH ($SIZE)"
    echo "=========================================="
    echo ""
    echo "安装到手机 (需要 adb):"
    echo "  adb install -r $APK_PATH"
    echo ""
else
    echo "  ❌ APK 未找到，构建可能失败"
    exit 1
fi
